package com.fqw.util;

import java.io.File;
import java.io.IOException;
import java.io.InputStream;
import java.util.ArrayList;
import java.util.List;

public class BackgroundUpload {
	public List<String> traverseFolder2(String path) {
		List<String> pcs=new ArrayList<String>();
	
        File file = new File(path);
        if (file.exists()) {
            File[] files = file.listFiles();
            if (files.length == 0) {
                System.out.println("�ļ����ǿյ�!");
                // return;
            } else {
                for (File file2 : files) {
                    if (file2.isDirectory()) {
                       // System.out.println("�ļ���:" + file2.getPath());
                        traverseFolder2(file2.getPath());
                        pcs.add(file2.getPath());
                    } else {
                        //System.out.println("�ļ�:" + file2.getPath());
                        pcs.add(file2.getPath());
                    }
                }
            }
        } else {
            System.out.println("�ļ�������!");
        }
        return pcs;
    }
}
