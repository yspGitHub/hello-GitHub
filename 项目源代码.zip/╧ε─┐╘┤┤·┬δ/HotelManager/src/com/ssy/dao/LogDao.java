package com.ssy.dao;

import java.util.Calendar;
import java.util.TimeZone;
import java.util.Vector;

import com.ssy.entity.Log;

public class LogDao extends MySqlhelper{
	public int insert(Log log){
		int row=0;
		String sql="INSERT INTO tb_log(log_time,log_option,log_room,log_cus,log_money,log_user) VALUES(?,?,?,?,?,?)";
		Object[] para={log.getTime(),log.getOption(),log.getRoomId(),log.getCusId(),log.getMoney(),log.getUserId()};
		System.out.println(log.getTime()+"'1'"+log.getOption()+log.getRoomId()+log.getCusId()+log.getMoney()+log.getUserId());
		try {
			row=this.getUpdate(sql, para);
			System.out.println(211);
		} catch (Exception e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}finally{
			this.close();
		}
		return row;
		
	}
	public Vector<Vector> find(){
		
		String sql="SELECT log_time,log_cus,log_option,log_room,log_money,log_user FROM tb_log";
		Vector<Vector> logs=new Vector<Vector>();
		try {
			this.getSeek(sql, null);
			while (rs.next()) {
				String time = rs.getString(1);
				String cusId = rs.getString(2);
				String option = rs.getString(3);
				String roomId=rs.getString(4);
				String money=rs.getString(5);
				String userId=rs.getString(6);
				Vector v = new Vector();
				v.add(time);
				v.add(cusId);
				v.add(option);
				v.add(roomId);
				v.add(money);
				v.add(userId);
				logs.add(v);

			}
		} catch (Exception e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}finally{
			this.close();
		}
		
		return logs;
		
	}
	public Vector<Vector> mfind(String info){
		
		String sql="SELECT log_time,log_cus,log_option,log_room,log_money,log_user FROM tb_log WHERE log_time LIKE '%"+info+"%' OR log_option LIKE '%"+info+"%' OR log_room LIKE '%"+info+"%' OR log_cus LIKE '%"+info+"%' OR log_user LIKE '%"+info+"%'";
		Vector<Vector> logs=new Vector<Vector>();
		try {
			this.getSeek(sql, null);
			while (rs.next()) {
				String time = rs.getString(1);
				String cusId = rs.getString(2);
				String option = rs.getString(3);
				String roomId=rs.getString(4);
				String money=rs.getString(5);
				String userId=rs.getString(6);
				Vector v = new Vector();
				v.add(time);
				v.add(cusId);
				v.add(option);
				v.add(roomId);
				v.add(money);
				v.add(userId);
				logs.add(v);

			}
		} catch (Exception e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}finally{
			this.close();
		}
		
		return logs;
	
	}
	public int delete(int id){
		String sql="delete from tb_log where log_room=?";
		Object[] para={id};
		int row=0;
		try {
			row=this.getUpdate(sql, para);
		} catch (Exception e) {
			// TODO: handle exception
		}finally{
			this.close();
		}
		return row;
		
	}
	public int countMoney(){
		Calendar cld=Calendar.getInstance(TimeZone.getTimeZone("GMT+08:00"));
	
		int count=0;
		int year=cld.get(Calendar.YEAR);
		 int  month = cld.get(Calendar.MONTH) + 1;   //��ȡ�·ݣ�0��ʾ1�·�
		String  sql="SELECT SUM(log_money) FROM tb_log WHERE log_time LIKE '%"+year+"-"+month+"%'";
		try {
			this.getSeek(sql, null);
			while(rs.next()){
				count=rs.getInt(1);
			}
		} catch (Exception e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}finally{
			this.close();
		}
		return count;
		
	}

}
