package com.ssy.dao;

import java.util.List;
import java.util.Vector;

import com.ssy.entity.UserInfo;

public interface IUserInfoDao {
  public int insert(UserInfo user);
  public  Vector<Vector> seek();
  public int update(String id,String password);
  public int delete(String id);
  public String findPass(String id);
  public Vector seek(String id);
  public int update(String id,UserInfo user);
  public String findAuth(String id);
  public String findUser(String id);
  public Vector<Vector> mfind(String info);
  public List<UserInfo> login(String username,String password);
}
