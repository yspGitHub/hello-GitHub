package com.ssy.dao;

import java.util.Vector;

import com.ssy.entity.Room;

public interface IRoomDao {
	 public int insert(Room room) throws Exception;
	  public Vector<Vector> find(String stateName) throws Exception;
	  public Vector<Vector> find() throws Exception;
	  public Vector<Vector> find(String stateName,String typeName) throws Exception;

	  public int delete(String id) throws Exception;
	  public int openRoom(String id,String roomState) throws Exception;
	  public Vector<Vector> vagueFind(String id) throws Exception;
	  public Vector<Vector> typeFind(String typeName) throws Exception;
	  public Vector<Vector> typeFind() throws Exception;
	  public int update(String id, String floor, String type) throws Exception;
	 
}
