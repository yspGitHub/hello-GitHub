package com.ssy.dao.impl;

import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;
import java.util.Vector;

import com.ssy.dao.IUserInfoDao;
import com.ssy.dao.MySqlhelper;
import com.ssy.entity.UserInfo;

public class UserInfoDaoImpl extends MySqlhelper implements IUserInfoDao{

	@Override
	public int insert(UserInfo user){
		int row=0;
		String sql="INSERT INTO tb_user VALUES(?,?,?,?,?,?)";
		Object[] para={user.getUserId(),user.getUserName(),user.getUserPassword(),user.getAuthority(),user.getAdress(),user.getTel()};
	
		try{
		row=this.getUpdate(sql, para);
		}catch(Exception e){
			
			e.printStackTrace();
		}finally{
			this.close();
		}
		
		
		return row;
		// TODO Auto-generated method stub
		
	}

	@Override
	public  Vector<Vector> seek(){
		// TODO Auto-generated method stub
		String sql="SELECT * FROM tb_user";
		 Vector<Vector> users=new Vector<Vector>();
		try {
			this.getSeek(sql, null);
			while(rs.next()){
				Vector user=new Vector();
				String userId=rs.getString("user_id");
				String userName=rs.getString("user_name");
				String userAdress=rs.getString("user_adress");
				int authority=rs.getInt("user_authority");
				String tel=rs.getString("user_tel");
				String password=rs.getString("user_password");
				user.add(userId);
				user.add(userName);
				user.add(userAdress);
			
				user.add(tel);
				user.add(authority);
			
				users.add(user);
			}
		} catch (Exception e) {
			// TODO: handle exception
	
		}finally {
			this.close();
		}
		
		System.out.println(users.size()+"");
		return users;
	}

	@Override
	public int update(String id,String password){
		// TODO Auto-generated method stub
		String sql="update tb_user set user_password=? where user_id=?";
		System.out.println("id:"+id+"password:"+password);
		Object[] para = {password,id};
		int row=0;
		try {
			row=this.getUpdate(sql, para);
		} catch (Exception e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		
		return row;
	}
	public List<UserInfo> login(String username,String password){
		List<UserInfo> users=new ArrayList<UserInfo>();
		
		String sql="SELECT * FROM tb_user where user_id=? and user_password=?";
		Object[] para={username,password};
	
			try {
				this.getSeek(sql, para);
				while(rs.next()){
					UserInfo user=new UserInfo();
					user.setUserId(rs.getString("user_id"));
					user.setAuthority(rs.getInt("user_authority"));
					users.add(user);
									}
			}catch (Exception e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}finally{
				this.close();
			}
		return users;
	}
	public int delete(String id){
		String sql="delete from tb_user where user_id=?";
		Object[] para={id};
		int row=0;
		try {
			row=this.getUpdate(sql, para);
		} catch (Exception e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}finally{
			this.close();
		}
		return row;
		
	}
	public String findPass(String id){
		String sql="select user_password from tb_user where user_id=?";
		String password="";
		Object[] para={id};
		try {
			this.getSeek(sql, para);
			while(rs.next()){
				password=rs.getString(1);
				
			}
		} catch (Exception e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}finally{
			this.close();
		}
		return password;
	}
	

	@Override
	public String findAuth(String id) {
		// TODO Auto-generated method stub
		
		return null;
	}

	@Override
	public String findUser(String id) {
		// TODO Auto-generated method stub
		String sql="SELECT user_id FROM tb_user WHERE user_id =?";
		String userId = null;
		System.out.println(sql);
		Object[] para={id};
		try {
			this.getSeek(sql, para);
			while(rs.next()){
				userId=rs.getString(1);
			}
		} catch (Exception e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}finally {
			this.close();
		}
		return userId;
	}
	public Vector<Vector> mfind(String info){
		
		Vector<Vector> users=new Vector<Vector>();
		try {
	
		String sql="SELECT user_id,user_name,user_authority,user_adress,user_tel FROM tb_user WHERE user_id LIKE '%"+info+"%' OR user_name LIKE '%"+info+"%' OR user_tel LIKE '%"+info+"%'";
		
	
		this.getSeek(sql, null);
		while(rs.next()){
			Vector user=new Vector();
			String userId=rs.getString("user_id");
			String userName=rs.getString("user_name");
			String userAdress=rs.getString("user_adress");
			int authority=rs.getInt("user_authority");
			String tel=rs.getString("user_tel");
		
			user.add(userId);
			user.add(userName);
			user.add(userAdress);
			user.add(tel);
			user.add(authority);		
			users.add(user);
			System.out.println(1);
		}
	} catch (Exception e) {
		System.out.println(e.getMessage()+"��ѯ����ʧ��");
		// TODO: handle exception
	}finally{
		this.close();
	}
	return users;
		
	}
	public  Vector seek(String id){
		// TODO Auto-generated method stub
		String sql="SELECT * FROM tb_user where user_id=?";
		Object[] para={id};
		 //Vector<Vector> users=new Vector<Vector>();
		Vector user=new Vector();
		try {
			this.getSeek(sql, para);
			while(rs.next()){
			
				String userId=rs.getString("user_id");
				String userName=rs.getString("user_name");
				String userAdress=rs.getString("user_adress");
				int authority=rs.getInt("user_authority");
				String tel=rs.getString("user_tel");
				String password=rs.getString("user_password");
				user.add(userId);
				user.add(userName);
				user.add(userAdress);
			
				user.add(tel);
				user.add(authority);
			
				//users.add(user);
			}
		} catch (Exception e) {
			// TODO: handle exception
	
		}finally {
			this.close();
		}
		
		//System.out.println(users.size()+"");
		return user;
	}
	public int update(String id,UserInfo user){
		String sql="update tb_user set user_name=?,user_tel=?,user_adress=?,user_authority=? where user_id=?";
		Object[] para={user.getUserName(),user.getTel(),user.getAdress(),user.getAuthority(),id};
		int row=0;
		try {
			System.out.println(user.getUserName()+user.getTel()+user.getAdress()+user.getAuthority()+id);
			row=this.getUpdate(sql, para);
		} catch (Exception e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}finally{
			this.close();
		}
		
		return row;
		
	}
	
}
