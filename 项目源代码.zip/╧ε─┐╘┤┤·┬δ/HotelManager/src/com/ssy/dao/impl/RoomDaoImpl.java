package com.ssy.dao.impl;

import java.util.Vector;

import com.ssy.dao.IRoomDao;
import com.ssy.dao.MySqlhelper;
import com.ssy.entity.Room;
import com.ssy.entity.UserInfo;

public class RoomDaoImpl extends MySqlhelper implements IRoomDao{

	@Override
	public int insert(Room room) throws Exception {
		// TODO Auto-generated method stub
		int row=0;
		try {
			String sql="INSERT INTO tb_room(room_id,room_flower,room_type,room_state,room_tel) VALUES(?,?,?,?,?)";
			
			Object[] para={room.getId(),room.getFlower(),room.getType(),room.getSate(),room.getTel()};
		
			row=this.getUpdate(sql, para);
			
		} catch (Exception e) {
		System.out.println(e.getMessage()+"����ʧ��");
	
		}finally{
			this.close();
		}
		
		
		return row;
		
	}

	@Override
	public Vector<Vector> find(String stateName) throws Exception {
		// TODO Auto-generated method stub
		Vector<Vector> rooms=new Vector<Vector>();
		try {
			String sql="SELECT a.room_id,a.room_flower,b.type_name,a.room_state,a.room_tel FROM tb_room a,tb_type b WHERE a.room_type=b.type_id and a.room_state=? ORDER BY b.type_id DESC,a.room_flower DESC,a.room_id ASC";
			Object[] para={stateName};
			System.out.println(stateName);
			this.getSeek(sql, para);
			while(rs.next()){
				String id =rs.getString("room_id");
				int flower=rs.getInt("room_flower");
				String type=rs.getString("type_name");
				String state=rs.getString("room_state");
				int tel=rs.getInt("room_tel");
				
				
				//������ʱ���϶����װÿһ�е���������Ϣ
				Vector v = new Vector();
				//����������������
				v.add(id);
				v.add(flower);
				v.add(type);
				v.add(state);
				v.add(tel);
			
				rooms.add(v);
			}
		} catch (Exception e) {
			System.out.println(e.getMessage()+"��ѯ����ʧ��");
			// TODO: handle exception
		}finally{
			this.close();
		}
		return rooms;
		
	}

	@Override
	public int update(String id,String floor,String type){
		// TODO Auto-generated method stub
		String sql="UPDATE tb_room SET room_flower=?,room_type=? WHERE room_id=?";
		Object[] para={floor,type,id};
		System.out.println(floor+"  "+type+"  "+id);
		int row=0;
		try {
			row=this.getUpdate(sql, para);
		} catch (Exception e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}finally{
			this.close();
		}
		return row;
	}

	@Override
	public int delete(String id) throws Exception {
		// TODO Auto-generated method stub
		String sql="DELETE FROM tb_room WHERE room_id=?";
		Object[] para={id};
		int row=this.getUpdate(sql, para);
		
		return row;
	}
	public int openRoom(String id,String roomState) throws Exception{
		
		String sql="UPDATE tb_room SET room_state=? WHERE room_id=?";
		Object[] para={roomState,id};
		int row=0;
		try {
			row=this.getUpdate(sql, para);
		} catch (Exception e) {
			// TODO: handle exception
		}finally{
			this.close();
		}
		return row;
		
	}

	@Override
	public Vector<Vector> vagueFind(String roomId) throws Exception {
		// TODO Auto-generated method stub
		Vector<Vector> rooms=new Vector<Vector>();
		try {
	
		String sql="SELECT a.room_id,a.room_flower,b.type_name,a.room_state,a.room_tel FROM tb_room a,tb_type b WHERE a.room_type=b.type_id AND room_id LIKE '%"+roomId+"%' ORDER BY b.type_id DESC,a.room_flower DESC,a.room_id ASC";
		
	
		this.getSeek(sql, null);
		while(rs.next()){
			String id =rs.getString("room_id");
			int flower=rs.getInt("room_flower");
			String type=rs.getString("type_name");
			String state=rs.getString("room_state");
			String tel=rs.getString("room_tel");
			
			
			//������ʱ���϶����װÿһ�е���������Ϣ
			Vector v = new Vector();
			//����������������
			v.add(id);
			v.add(flower);
			v.add(type);
			v.add(state);
			v.add(tel);
		
			rooms.add(v);
		}
	} catch (Exception e) {
		System.out.println(e.getMessage()+"��ѯ����ʧ��");
		// TODO: handle exception
	}finally{
		this.close();
	}
	return rooms;
		
	}

	@Override
	public Vector<Vector> typeFind(String typeName) throws Exception {
		// TODO Auto-generated method stub
		Vector<Vector> rooms=new Vector<Vector>();
		try{
		String sql="SELECT a.room_id,a.room_flower,b.type_name,a.room_state,a.room_tel FROM tb_room a,tb_type b WHERE a.room_type=b.type_id AND b.type_name=? ORDER BY b.type_id DESC,a.room_flower DESC,a.room_id ASC";
		Object[] para={typeName};
		this.getSeek(sql, para);
	
		while(rs.next()){
			String id =rs.getString("room_id");
			int flower=rs.getInt("room_flower");
			String type=rs.getString("type_name");
			String state=rs.getString("room_state");
			String tel=rs.getString("room_tel");
			
			
			//������ʱ���϶����װÿһ�е���������Ϣ
			Vector v = new Vector();
			//����������������
			v.add(id);
			v.add(flower);
			v.add(type);
			v.add(state);
			v.add(tel);
		
	
			rooms.add(v);
		}
	} catch (Exception e) {
		System.out.println(e.getMessage()+"��ѯ����ʧ��");
		// TODO: handle exception
	}finally{
		this.close();
	}
	return rooms;
	}

	@Override
	public Vector<Vector> find() throws Exception {
		// TODO Auto-generated method stub
		Vector<Vector> rooms=new Vector<Vector>();
		try {
			String sql="SELECT a.room_id,a.room_flower,b.type_name,a.room_state,a.room_tel FROM tb_room a,tb_type b WHERE a.room_type=b.type_id ORDER BY b.type_id DESC,a.room_flower DESC,a.room_id ASC";
		
			
			this.getSeek(sql, null);
			while(rs.next()){
				String id =rs.getString("room_id");
				int flower=rs.getInt("room_flower");
				String type=rs.getString("type_name");
				String state=rs.getString("room_state");
				String tel=rs.getString("room_tel");
				
				
				//������ʱ���϶����װÿһ�е���������Ϣ
				Vector v = new Vector();
				//����������������
				v.add(id);
				v.add(flower);
				v.add(type);
				v.add(state);
				v.add(tel);
			
				rooms.add(v);
			}
		} catch (Exception e) {
			System.out.println(e.getMessage()+"��ѯ����ʧ��");
			// TODO: handle exception
		}finally{
			this.close();
		}
		return rooms;
	}

	@Override
	public Vector<Vector> typeFind() throws Exception {
		// TODO Auto-generated method stub
		Vector<Vector> rooms=new Vector<Vector>();
		try{
		String sql="SELECT a.room_id,a.room_flower,b.type_name,a.room_state,a.room_tel FROM tb_room a,tb_type b WHERE a.room_type=b.type_id ORDER BY b.type_id DESC,a.room_flower DESC,a.room_id ASC";
		
		this.getSeek(sql, null);
	
		while(rs.next()){
			String id =rs.getString("room_id");
			int flower=rs.getInt("room_flower");
			String type=rs.getString("type_name");
			String state=rs.getString("room_state");
			String tel=rs.getString("room_tel");
			
			
			//������ʱ���϶����װÿһ�е���������Ϣ
			Vector v = new Vector();
			//����������������
			v.add(id);
			v.add(flower);
			v.add(type);
			v.add(state);
			v.add(tel);
		
			rooms.add(v);
		}
	} catch (Exception e) {
		System.out.println(e.getMessage()+"��ѯ����ʧ��");
		// TODO: handle exception
	}finally{
		this.close();
	}
	return rooms;
	}

	@Override
	public Vector<Vector> find(String stateName, String typeName) throws Exception {
		// TODO Auto-generated method stub
		Vector<Vector> rooms=new Vector<Vector>();
		try {
			String sql="SELECT a.room_id,a.room_flower,b.type_name,a.room_state,a.room_tel FROM tb_room a,tb_type b WHERE a.room_type=b.type_id and a.room_state=? and b.type_name=? ORDER BY b.type_id DESC,a.room_flower DESC,a.room_id ASC";
			Object[] para={stateName,typeName};
			System.out.println(stateName+"-"+typeName);
			System.out.println(stateName);
			this.getSeek(sql, para);
			while(rs.next()){
				String id =rs.getString("room_id");
				int flower=rs.getInt("room_flower");
				String type=rs.getString("type_name");
				String state=rs.getString("room_state");
				String tel=rs.getString("room_tel");
				
				
				//������ʱ���϶����װÿһ�е���������Ϣ
				Vector v = new Vector();
				//����������������
				v.add(id);
				v.add(flower);
				v.add(type);
				v.add(state);
				v.add(tel);
			
				rooms.add(v);
			}
		} catch (Exception e) {
			System.out.println(e.getMessage()+"��ѯ����ʧ��");
			// TODO: handle exception
		}finally{
			this.close();
		}
		return rooms;
	}





	
	

}
