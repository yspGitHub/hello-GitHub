package com.ssy.dao;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;

public class MySqlhelper {
	public Connection conn=null;
	public PreparedStatement stmt=null;
	public ResultSet rs=null;
	//��������
	public void open() throws ClassNotFoundException, SQLException{
		
			Class.forName("com.mysql.jdbc.Driver");
			String url="jdbc:mysql://localhost:3306/hotel";
			String uId="root";
			String uPwd="";
			conn=DriverManager.getConnection(url,uId,uPwd);
		
	}
	//�������
	public void getStatement(String sql,Object[] para) throws Exception{
		try {
			open();
	
			stmt=conn.prepareStatement(sql);
			if(para!=null){
				for(int i=0;i<para.length;i++){
					stmt.setObject(i+1, para[i]);
				}
			}
		} catch (Exception e) {
			throw new Exception(e.getMessage()+"ִ������ʧ��");
		}
	}
	//ִ�и��²���
	public int getUpdate(String sql,Object[] para) throws Exception{
		int row=0;
		getStatement(sql,para);
	
		row=stmt.executeUpdate();
		return row;
	}
	//ִ�в�ѯ����
	public void getSeek(String sql,Object[] para) throws Exception{
		try {
			getStatement(sql,para);
			rs=stmt.executeQuery();
		} catch (Exception e) {
			throw new Exception(e.getMessage()+"��ѯʧ��");
		}
	}
	//�ر�
	public void close(){
		try {
			if(rs!=null) rs.close();
			if(stmt!=null) stmt.close();
			if(conn!=null) conn.close();
		} catch (Exception e) {
			try {
				throw new Exception(e.getMessage()+"�ر�ʧ��");
			} catch (Exception e1) {
				// TODO Auto-generated catch block
				e1.printStackTrace();
			}
		}
	}
}
