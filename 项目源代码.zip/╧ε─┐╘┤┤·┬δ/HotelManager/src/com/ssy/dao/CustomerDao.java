package com.ssy.dao;

import java.util.Vector;

import com.ssy.entity.Customer;
import com.ssy.entity.Room;

public class CustomerDao extends MySqlhelper{
	public Vector<Vector> find(){
		Vector<Vector> customers = new Vector<Vector>();
		String sql = "SELECT a.cus_id,a.cus_name,a.cus_tel,a.cus_room,b.vip_name,a.cus_open,a.cus_leave,a.cus_order FROM tb_customer a,tb_vip b WHERE a.cus_vip=b.vip_id";


		try {
			getSeek(sql, null);
			while (rs.next()) {
				String idCard = rs.getString("cus_id");
				String name =rs.getString("cus_name");
				String tel = rs.getString("cus_tel");
				String roomId=rs.getString("cus_room");
				String vip=rs.getString("vip_name");
				String open=rs.getString("cus_open");
				String leave=rs.getString("cus_leave");
				String order=rs.getString("cus_order");
				Vector customer = new Vector();
				customer.add(idCard);
				customer.add(name);
				customer.add(tel);
				customer.add(roomId);
				customer.add(vip);
				customer.add(open);
				customer.add(leave);
				customer.add(order);
				customers.add(customer);
			}
			
		} catch (Exception e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}finally{
			this.close();
		}
		

		
		return customers;
	}
	public Vector<Vector> mfind(String info){
		Vector<Vector> customers = new Vector<Vector>();
		String sql = "SELECT a.cus_id,a.cus_name,a.cus_tel,a.cus_room,b.vip_name,a.cus_open,a.cus_leave,a.cus_order FROM tb_customer a,tb_vip b"+
		" WHERE a.cus_vip=b.vip_id AND cus_id LIKE '%"+info+"%' OR a.cus_vip=b.vip_id AND cus_name LIKE '%"+info+"%' OR a.cus_vip=b.vip_id AND cus_tel LIKE '%"+info+"%' OR a.cus_vip=b.vip_id AND cus_room LIKE '%"+info+"%'";
		

		try {
			getSeek(sql, null);
			while (rs.next()) {
				String idCard = rs.getString("cus_id");
				String name =rs.getString("cus_name");
				String tel = rs.getString("cus_tel");
				String roomId=rs.getString("cus_room");
				String vip=rs.getString("vip_name");
				String open=rs.getString("cus_open");
				String leave=rs.getString("cus_leave");
				String order=rs.getString("cus_order");
				Vector customer = new Vector();
				customer.add(idCard);
				customer.add(name);
				customer.add(tel);
				customer.add(roomId);
				customer.add(vip);
				customer.add(open);
				customer.add(leave);
				customer.add(order);
				customers.add(customer);
			}
		
		}catch(Exception e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}finally{
			this.close();
		}
		

		
	
		return customers;
	}
	public Vector find(String Card){
		Vector customer = new Vector();
		String sql = "SELECT a.cus_id,a.cus_name,a.cus_tel,a.cus_room,b.vip_name,a.cus_order FROM tb_customer a,tb_vip b WHERE a.cus_vip=b.vip_id and cus_id=?";
		Object[] para={Card};
		try {
			getSeek(sql, para);
		
		while (rs.next()) {
			String idCard = rs.getString("cus_id");
			String name = rs.getString("cus_name");
			String tel = rs.getString("cus_tel");
			String roomId=rs.getString("cus_room");
			String vip=rs.getString("vip_name");
			String order=rs.getString("cus_order");
			
			customer.add(idCard);
			customer.add(name);
			customer.add(tel);
			customer.add(roomId);
			customer.add(vip);
			customer.add(order);
		}

		}catch (Exception e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}finally{
			this.close();
		}
		return customer;
	}
	public int insert(Customer customer){
		int row=0;
		try {
			String sql="insert into tb_customer(cus_id,cus_name,cus_tel,cus_room,cus_vip,cus_open,cus_leave) values(?,?,?,?,?,?,?)";
			System.out.println(customer.getIdCard()+"+"+customer.getName()+"+"+customer.getTel()+"+"+customer.getRoom().getId()+"+"+customer.getVip().getId()+"+"+customer.getOpen()+"+"+customer.getLeave());
			Object[] para={customer.getIdCard(),customer.getName(),customer.getTel(),customer.getRoom().getId(),customer.getVip().getId(),customer.getOpen(),customer.getLeave()};
		
			row=this.getUpdate(sql, para);
			
		} catch (Exception e) {
		System.out.println(e.getMessage()+"����ʧ��");
	
		}finally{
			this.close();
		}
		
		
		return row;
		
		
	}
	public int delete(String roomId){
		String sql="DELETE FROM tb_customer WHERE cus_room=?";
		Object[] para={roomId};
		int row=0;
		try {
			row = this.getUpdate(sql, para);
		} catch (Exception e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}finally{
			this.close();
		}
		
		return row;
	}

}
