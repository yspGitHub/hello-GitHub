package com.ssy.dao;

import java.util.Vector;

import com.ssy.entity.Type;



public class TypeDao extends MySqlhelper{
	public int insert(Type type){
		String sql = "insert into tb_type(type_name,type_price) values(?,?)";
		Object[] para = {type.getName(), type.getPrice() };
		int row=0;
		try {
			row = this.getUpdate(sql, para);
		} catch (Exception e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		return row;

	}

	public Vector<Vector> find(){
		Vector<Vector> types = new Vector<Vector>();
		String sql = "select * from tb_type";
		try {
			getSeek(sql, null);
			while (rs.next()) {
				int id = rs.getInt(1);
				String name = rs.getString(2);
				int price = rs.getInt(3);
				Vector v = new Vector();
				v.add(id);
				v.add(name);
				v.add(price);
				types.add(v);

			}
		} catch (Exception e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	
		return types;

	}
	public Vector query(String typeName){
		Vector type=new Vector<>();
		String sql="SELECT * FROM tb_type WHERE type_name=?";
		Object[] para={typeName};
		try {
			this.getSeek(sql, para);
			while(rs.next()){
				int id = rs.getInt(1);
				String name = rs.getString(2);
				int price = rs.getInt(3);
				type.add(id);
				type.add(name);
				type.add(price);
			}
			
		} catch (Exception e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	
		return type;
		
		
	}

	public int delete(int id) {
		String sql1="delete from tb_room where room_type=?";
		String sql2 = "DELETE FROM tb_type WHERE type_id=?";
		Object[] para = { id };
		int row=0;
		try {
			System.out.println(id);
				this.getUpdate(sql1, para);
			row = this.getUpdate(sql2, para);
		} catch (Exception e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}finally{
			this.close();
		}
		return row;
	}
	public int update(Type type,String id){
		
	String sql="UPDATE tb_type SET type_name=?,type_price=? WHERE type_id=?"; 
	Object[] para={type.getName(),type.getPrice(),id};
	int row=0;
	try {
		row=this.getUpdate(sql, para);
	} catch (Exception e) {
		// TODO Auto-generated catch block
		e.printStackTrace();
	}finally{
		this.close();
	}
		return row;
		
		
	}
}
