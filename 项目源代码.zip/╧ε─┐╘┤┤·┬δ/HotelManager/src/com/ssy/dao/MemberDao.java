package com.ssy.dao;

import java.util.Vector;

import com.ssy.entity.Member;

public class MemberDao extends MySqlhelper{
	  public Vector find(String idCard) throws Exception{
		  Vector vip=new Vector();
			try {
				String sql="SELECT a.vip_name,a.vip_discount,b.me_name,b.me_tel,b.me_integration,a.vip_id FROM tb_vip a,tb_member b WHERE a.vip_id=b.me_vip AND b.me_id=?";
				Object[] para={idCard};
				System.out.println(idCard+"mm");
				this.getSeek(sql, para);
				while(rs.next()){
					String vipName=rs.getString(1);
					int count=rs.getInt(2);
					String name=rs.getString(3);
					String tel=rs.getString(4);
					int integration=rs.getInt(5);
					int id=rs.getInt(6);
					vip.add(vipName);
					vip.add(count);
					vip.add(name);
					vip.add(tel);
					vip.add(integration);
					vip.add(id);
					
				
					
				}
			} catch (Exception e) {
				System.out.println(e.getMessage()+"��ѯ����ʧ��");
				// TODO: handle exception
			}finally{
				this.close();
			}
			return vip;
		  
	  }
	  public Vector<Vector> find() throws Exception{
		  
			Vector<Vector> members=new Vector<Vector>();

			try {
				String sql="SELECT a.me_id,a.me_name,a.me_tel,b.vip_name,a.me_integration FROM tb_member a,tb_vip b WHERE a.me_vip=b.vip_id";
			
			
				this.getSeek(sql, null);
			
				while(rs.next()){
					  Vector member=new Vector();
					String idCard=rs.getString(1);
					String name=rs.getString(2);
					String tel=rs.getString(3);
					String vipName=rs.getString(4);
					int integration=rs.getInt(5);
			
					member.add(idCard);
			
					member.add(name);
					member.add(tel);
					member.add(vipName);
					member.add(integration);
					members.add(member);
					
				
					
				}
			} catch (Exception e) {
				System.out.println(e.getMessage()+"��ѯ����ʧ��");
				// TODO: handle exception
			}finally{
				this.close();
			}
			
			return members;
		  
		  
	  }
	  public Vector<Vector> mfind(String info){
		  String sql="SELECT a.me_id,a.me_name,a.me_tel,b.vip_name,a.me_integration FROM tb_member a,tb_vip b WHERE a.me_vip=b.vip_id AND a.me_id LIKE '%"+info+"%' OR a.me_vip=b.vip_id  AND a.me_name LIKE '%"+info+"%' OR a.me_vip=b.vip_id AND a.me_tel LIKE '%"+info+"%'";
			Vector<Vector> members=new Vector<Vector>();
			System.out.println("ssy");
		  try {
			this.getSeek(sql, null);
			while(rs.next()){
				  Vector member=new Vector();
				String idCard=rs.getString(1);
				String name=rs.getString(2);
				String tel=rs.getString(3);
				String vipName=rs.getString(4);
				int integration=rs.getInt(5);
		
				member.add(idCard);
		
				member.add(name);
				member.add(tel);
				member.add(vipName);
				member.add(integration);
				members.add(member);
			}	
			
		} catch (Exception e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}finally{
			this.close();
		}
		 
		return members;
	  }
	  public int insert(Member member){
		  int row=0;
			try {
				String sql="INSERT INTO tb_member VALUES(?,?,?,?,?)";
				System.out.println(member.getId()+"  "+member.getVip().getId()+"  "+member.getTel()+"  "+member.getName()+"  "+member.getIntegration());
				Object[] para={member.getId(),member.getVip().getId(),member.getTel(),member.getName(),member.getIntegration()};
			
				row=this.getUpdate(sql, para);
				
			} catch (Exception e) {
			System.out.println(e.getMessage()+"����ʧ��");
		
			}finally{
				this.close();
			}
			
			
			return row;
		  
	  }
	  public int update(String id,int intergation){
		  String sql="UPDATE tb_member SET me_integration=? WHERE me_id=?";
		  Object[] para={intergation,id};
		  System.out.println(intergation+"   "+id);
		  int row=0;
		  try {
			row=this.getUpdate(sql, para);
		} catch (Exception e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		return row;
		  
	  }
	  public int update(int vip,String id){
		  String sql="UPDATE tb_member SET me_vip=? WHERE me_id=?";
		  Object[] para={vip,id};
		  System.out.println(vip+"   "+id);
		  int row=0;
		  try {
			row=this.getUpdate(sql, para);
		} catch (Exception e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		return row;
		  
	  }
	  public int delete(String id){
		  String sql="delete from tb_member where me_id=?";
		  Object[] para={id};
		  int row=0;
		  try {
			row=this.getUpdate(sql, para);
		} catch (Exception e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}finally{
			this.close();
		}
		return row;
		  
	  }
	  public int update(String id,Member member){
		  String sql="update tb_member set me_name=?,me_vip=?,me_tel=? where me_id=?";
		  Object[] para={member.getName(),member.getVip().getId(),member.getTel(),member.getId()};
		  int row=0;
		  try {
			row=this.getUpdate(sql, para);
		} catch (Exception e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		return row;
		  
	  }
}
