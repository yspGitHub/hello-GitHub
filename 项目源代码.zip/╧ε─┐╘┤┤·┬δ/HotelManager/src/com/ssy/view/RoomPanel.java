package com.ssy.view;

import java.awt.CardLayout;
import java.awt.Color;
import java.awt.Component;
import java.awt.Dimension;
import java.awt.Font;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.awt.event.ItemEvent;
import java.awt.event.ItemListener;
import java.awt.event.KeyEvent;
import java.awt.event.KeyListener;
import java.awt.event.MouseEvent;
import java.awt.event.MouseListener;
import java.util.Calendar;
import java.util.TimeZone;
import java.util.Vector;

import javax.swing.ImageIcon;
import javax.swing.JButton;
import javax.swing.JComboBox;
import javax.swing.JLabel;
import javax.swing.JOptionPane;
import javax.swing.JPanel;
import javax.swing.JScrollPane;
import javax.swing.JTable;
import javax.swing.JTextField;
import javax.swing.ListSelectionModel;
import javax.swing.SwingConstants;
import javax.swing.border.Border;
import javax.swing.table.DefaultTableCellRenderer;
import javax.swing.table.DefaultTableModel;
import javax.swing.table.JTableHeader;
import javax.swing.table.TableCellRenderer;

import com.ssy.biz.IRoomBiz;
import com.ssy.biz.impl.RoomBizImpl;
import com.ssy.dao.CustomerDao;
import com.ssy.dao.LogDao;
import com.ssy.dao.TypeDao;
import com.ssy.entity.Log;
import com.ssy.entity.Room;



enum ����״̬{
	δ����,������,������
}

public class RoomPanel extends JPanel{
	
	IRoomBiz irz=new RoomBizImpl();
	TypeDao td=new TypeDao();
	private JButton jb1,jb2,jb3,jb4,jb5,jb6,jb7,jb8,jb9,jba;
	
	private JComboBox jcb1,jcb2,jcb3,jcb4,jcb5;
	private JLabel jl1;
	private JTextField jtx1;
	private JTable jt;
	public static String id;
	private static final String fstate="------------״̬------------";
	private static final String ftype="------------����------------";
	private String stateName;
	public static String typeName;
	Vector title = new Vector();
	String nowtime;
	DefaultTableModel tableModel = new DefaultTableModel();
	JScrollPane jsp;
	public Room room;
	Vector<Vector> vector;
	Vector<Vector> types;
	public RoomPanel(){
		init();
	}
	public RoomPanel(int i){
		
	}
	public String getnowtime(){
		Calendar cld=Calendar.getInstance(TimeZone.getTimeZone("GMT+08:00"));
		
		int year=cld.get(Calendar.YEAR);
		
		 int month = cld.get(Calendar.MONTH) + 1;   //��ȡ�·ݣ�0��ʾ1�·�
		  int day = cld.get(Calendar.DAY_OF_MONTH);    //��ȡ��ǰ����
		   
		  //int first = cld.getActualMinimum(c.DAY_OF_MONTH);    //��ȡ������С����
		  //int last = cld.getActualMaximum(c.DAY_OF_MONTH);    //��ȡ�����������
		  int hour = cld.get(Calendar.HOUR_OF_DAY);       //��ȡ��ǰСʱ
		  int mintue = cld.get(Calendar.MINUTE);          //��ȡ��ǰ����
		  int second = cld.get(Calendar.SECOND);    
		  String nowtime=year + "-" + month + "-"+ day + " "+hour + ":" + mintue +":" + second;
		 
		  return nowtime;
	}
	public void find(){
		try {
			if(stateName.equals(fstate)){
				vector=new Vector<Vector>();
				vector=irz.find();
				tableModel.setDataVector(vector, title);	
				
			}else{
				vector=new Vector<Vector>();
				vector=irz.find(stateName);
				tableModel.setDataVector(vector, title);
			}
			
			
		
		} catch (Exception e) {
			// TODO Auto-generated catch block
			
			e.printStackTrace();
		}
	}
	public void refresh(){
		vector=new Vector<Vector>();
		try {
			vector=irz.find();
		} catch (Exception e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		findType();
		jcb1.setSelectedItem(fstate);
		jcb2.setSelectedItem(ftype);	
		tableModel.setDataVector(vector, title);
	}
	public void findType(){
		try {
			types=new Vector<Vector>();
			types=td.find();
			jcb2.removeAllItems();
			jcb2.addItem(ftype);
			for(Vector type:types){
				
				jcb2.addItem(type.get(1));
				
			}
			

			
		} catch (Exception e1) {
			// TODO: handle exception
			e1.printStackTrace();
		}
	}

	public void init() {
		this.setOpaque(false);
		this.setBounds(0, 0, 1200, 400);
		this.setLayout(null);
		this.setBackground(Color.white);
		jb1 = new JButton("��������");
		jb1.setBounds(1000, 230, 120, 40);
		jb1.setBackground(Color.white);
		jb1.setOpaque(false);
		jb1.setForeground(Color.black);
		jb1.setFont(new Font("����", Font.BOLD, 20));
		jb1.setFocusPainted(false);
		jb2=new JButton("ɾ������");
		jb2.setBounds(1000,280,120,40);	
		jb2.setEnabled(false);
		jb2.setBackground(Color.white);
		jb2.setOpaque(false);
		jb2.setForeground(Color.black);
		jb2.setFont(new Font("����", Font.BOLD, 20));
		jb2.setFocusPainted(false);
		jb3=new JButton("�޸ķ���");
		jb3.setBounds(1000,330,120,40);
		jb3.setEnabled(false);
		jb3.setBackground(Color.white);
		jb3.setOpaque(false);
		jb3.setForeground(Color.black);
		jb3.setFont(new Font("����", Font.BOLD, 20));
		jb3.setFocusPainted(false);
		jb4=new JButton("����");
		jb4.setBounds(1000,80,120,40);
		jb4.setEnabled(false);
		jb4.setBackground(Color.white);
		jb4.setOpaque(false);
		jb4.setForeground(Color.black);
		jb4.setFont(new Font("����", Font.BOLD, 20));
		jb4.setFocusPainted(false);
		jb5=new JButton("�˷�");
		jb5.setBounds(1000,130,120,40);
		jb5.setBackground(Color.white);
		jb5.setOpaque(false);
		jb5.setForeground(Color.black);
		jb5.setFont(new Font("����", Font.BOLD, 20));
		jb5.setFocusPainted(false);
		jb5.setEnabled(false);
		jb6=new JButton("����");
		jb6.setBounds(1000,180,120,40);
		jb6.setEnabled(false);
		jb6.setBackground(Color.white);
		jb6.setOpaque(false);
		jb6.setForeground(Color.black);
		jb6.setFont(new Font("����", Font.BOLD, 20));
		jb6.setFocusPainted(false);
		jb7=new JButton("��������");
		jb7.setBounds(1000, 380, 120,40);
		jb7.setBackground(Color.white);
		jb7.setOpaque(false);
		jb7.setForeground(Color.black);
		jb7.setFont(new Font("����", Font.BOLD, 20));
		jb7.setFocusPainted(false);
		jb8=new JButton("ɾ������");
		jb8.setBounds(1000, 430, 120,40);
		jb8.setEnabled(false);
		jb8.setBackground(Color.white);
		jb8.setOpaque(false);
		jb8.setForeground(Color.black);
		jb8.setFont(new Font("����", Font.BOLD, 20));
		jb8.setFocusPainted(false);
		jb9=new JButton("�޸ķ���");
		jb9.setBounds(1000, 480, 120,40);
		jb9.setEnabled(false);
		jb9.setBackground(Color.white);
		jb9.setOpaque(false);
		jb9.setForeground(Color.black);
		jb9.setFont(new Font("����", Font.BOLD, 20));
		jb9.setFocusPainted(false);
		jcb1=new JComboBox();
		jcb1.setBounds(12, 10, 150, 30);
		jcb1.setBackground(Color.white);
//		jcb1.setOpaque(false);
		jcb2=new JComboBox<>();
		jcb2.setBackground(Color.white);
//		jcb2.setOpaque(false);
		jcb2.setBounds(200, 10,150,30);
		jcb2.addItem(ftype);
	
		jl1=new JLabel("����:");
		jl1.setFont(new Font("����", Font.BOLD, 20));
		jl1.setBounds(388, 10, 100, 30);
		jtx1=new JTextField();
		jtx1.setOpaque(false);
		jtx1.setFont(new Font("����", Font.BOLD, 20));
		jtx1.setBounds(453, 10, 150, 30);
		
		jba=new JButton("ˢ��");
		jba.setBounds(1000, 30, 120, 40);
		jba.setBackground(Color.white);
		jba.setOpaque(false);
		jba.setForeground(Color.black);
		jba.setFont(new Font("����", Font.BOLD, 20));
		jba.setFocusPainted(false);
		jcb1.addItem(fstate);
		jcb1.addItem("δ����");
		jcb1.addItem("������");
		jcb1.addItem("������");
		nowtime=this.getnowtime();
		findType();
		stateName=jcb1.getItemAt(0).toString();
		typeName=jcb2.getItemAt(0).toString();
		
		title.add("����");

		title.add("¥��");
		title.add("����");
		title.add("״̬");
		title.add("�绰");
			find();

			jt=new JTable(){
				   public boolean isCellEditable(int row, int column){
				       return false;
				   }
			};
			jt.setModel(tableModel);
			jt.validate();
			
			jt.setFont(new Font("����", Font.BOLD, 20));
			jt.setRowHeight(25);
			jt.getTableHeader().setFont(new Font("����", Font.BOLD, 20));			
			jt.setOpaque(false);
		    DefaultTableCellRenderer render = new DefaultTableCellRenderer(){ 
		    public Component getTableCellRendererComponent(JTable table, Object value, boolean isSelected, boolean hasFocus, int row, int column) {

		   	 		 setOpaque(false);
		   	 	 jt.setSelectionForeground(Color.black);
                	if(isSelected){
                		 if (row==jt.getSelectedRow()){
                			 setOpaque(true);
                			   jt.setSelectionForeground(Color.white);
                			 
                		 }
                	}
               
                return super.getTableCellRendererComponent(jt, value, true, false, row, column);
            }
        };      		    
		    jt.setDefaultRenderer(Object.class,render);	
		    jt.setSelectionBackground(new Color(149, 192, 247));
		 
			JTableHeader header = jt.getTableHeader();//��ȡͷ��   
	        header.setPreferredSize(new Dimension(30, 30)); 
			//header.setSize(new Dimension(60, 50));
	   header.setFont(new Font("����", Font.BOLD, 30));
	        header.setOpaque(false);//����ͷ��Ϊ͸��  
	        header.getTable().setOpaque(false);//����ͷ������ı���͸��  
	        header.setDefaultRenderer(new HeaderCellRenderer(){
	        	
	        });  
	        TableCellRenderer headerRenderer = header.getDefaultRenderer();   
	        if (headerRenderer instanceof JLabel)   
	        {  
	            ((JLabel) headerRenderer).setHorizontalAlignment(JLabel.CENTER);   
	            ((JLabel) headerRenderer).setOpaque(false);   
	        }  
			
			jsp = new JScrollPane();  
			jsp.getViewport().setOpaque(false);//��JScrollPane����Ϊ͸��  
			jsp.setOpaque(false);//���м��viewport����Ϊ͸��  
			jsp.setViewportView(jt);//װ�ر���  
			jsp.setColumnHeaderView(jt.getTableHeader());//����ͷ����HeaderView���֣�  
			jsp.getColumnHeader().setOpaque(false);//��ȡ��ͷ����������Ϊ͸�� 	        
			jsp.setBackground(Color.white);
			jsp.setBounds(10, 80, 930, 440);
			jt.getTableHeader().setReorderingAllowed(false);			
		this.add(jsp);//�����м�����������
		this.add(jb1);
		this.add(jb2);
		this.add(jb3);
		this.add(jb4);
		this.add(jb5);
		this.add(jb6);
		this.add(jb7);
		this.add(jb8);
		this.add(jb9);
		this.add(jcb1);
		this.add(jcb2);
		this.add(jl1);
		this.add(jtx1);
		this.add(jba);
		this.setVisible(true);		
		jt.addMouseListener(new MouseListener() {
			
			@Override
			public void mouseReleased(MouseEvent e) {
				// TODO Auto-generated method stub
				
			}
			
			@Override
			public void mousePressed(MouseEvent e) {
				// TODO Auto-generated method stub
				
			}
			
			@Override
			public void mouseExited(MouseEvent e) {
				// TODO Auto-generated method stub
				
			}
			
			@Override
			public void mouseEntered(MouseEvent e) {
				// TODO Auto-generated method stub
				
			}
			
			@Override
			public void mouseClicked(MouseEvent e) {
				// TODO Auto-generated method stub
				jb2.setEnabled(true);
				jb3.setEnabled(true);
				int row=jt.getSelectedRow();
				id=jt.getValueAt(row, 0).toString();
			
				
				System.out.println(id);
				Vector<Vector> staes=new Vector<Vector>();
				
				try {
					staes=irz.vagueFind(id);
					stateName=staes.get(0).get(3).toString();
					System.out.println(stateName+"ss");
						if(stateName.equals("δ����")){
						jb4.setEnabled(true);
						jb5.setEnabled(false);
						jb6.setEnabled(false);
						}
						if(stateName.equals("������")){
						jb5.setEnabled(true);
						jb4.setEnabled(false);
						jb6.setEnabled(false);}
						if(stateName.equals("������")){
							jb6.setEnabled(true);
							jb5.setEnabled(false);
							jb4.setEnabled(false);}
				} catch (Exception e1) {
					// TODO Auto-generated catch block
					e1.printStackTrace();
				}
			
			
				
			
			}
		});
		jb1.addActionListener(new ActionListener() {
			
			@Override
			public void actionPerformed(ActionEvent e) {
				// TODO Auto-generated method stub
				new InsertRoom();
			
//				/find();
				
			}
		});
		jba.addActionListener(new ActionListener() {
			
			@Override
			public void actionPerformed(ActionEvent e) {
				// TODO Auto-generated method stub
			
				refresh();
			}
		});
		jb2.addActionListener(new ActionListener() {
			
			@Override
			public void actionPerformed(ActionEvent e) {
				// TODO Auto-generated method stub
				try {
					int row = 0;
					
					int del=JOptionPane.showConfirmDialog(jb2, "��ȷ��Ҫɾ��"+id+"�ſͷ���","����", JOptionPane.YES_NO_OPTION, JOptionPane.QUESTION_MESSAGE);
					  if(del==JOptionPane.YES_OPTION){
						row=irz.delete(id);
					  }else{
						  return;
					  }
					
					
					if(row>0){
						System.out.println("ɾ���ɹ�");
						refresh();
					}
				} catch (Exception e1) {
					// TODO Auto-generated catch block
					e1.printStackTrace();
				}
			}
		});
		jb3.addActionListener(new ActionListener() {
			
			@Override
			public void actionPerformed(ActionEvent e) {
				// TODO Auto-generated method stub
				new UpdateRoom();
			}
		});
		jb4.addActionListener(new ActionListener() {
			
			@Override
			public void actionPerformed(ActionEvent e) {
				// TODO Auto-generated method stub
				int row=0;
				
				InsertCustomer ic=new InsertCustomer();
				System.out.println(ic.flag+"jjj");
			
			}
		});
		jb5.addActionListener(new ActionListener() {
			
			@Override
			public void actionPerformed(ActionEvent e) {
				// TODO Auto-generated method stub
				CustomerDao cd=new CustomerDao();
				LogDao ld=new LogDao();
				Vector<Vector> customers=cd.mfind(id);
				String cusid="";
			    for(Vector customer :customers){
			    	cusid=customer.get(0).toString();
			    }
				Log log=new Log();
				log.setCusId(cusid);
				log.setRoomId(id);
				log.setMoney("");
				log.setOption("�˷�");
				 Login lg=new Login(1);
					System.out.println(lg.UserId+"  lll");
					 log.setUserId(lg.UserId);
				log.setTime(nowtime);
				int row=0;
				try {
					
					int del=JOptionPane.showConfirmDialog(jt, "��ȷ��Ҫ��"+id+"�ſͷ���","����", JOptionPane.YES_NO_OPTION, JOptionPane.QUESTION_MESSAGE);
					  if(del==JOptionPane.YES_OPTION){
						  ld.insert(log);
							ld.find();
							cd.delete(id);
					row=irz.openRoom(id,����״̬.������.toString());
					  }
					if(row>0){
						
						JOptionPane.showMessageDialog(jsp, id+"�ŷ�������");
						if(!jcb1.getSelectedItem().equals(fstate)){
							find();
						}else{
						refresh();
						}
					}
				} catch (Exception e1) {
					// TODO Auto-generated catch block
					e1.printStackTrace();
				}
			}
		});
		jb6.addActionListener(new ActionListener() {
			
			@Override
			public void actionPerformed(ActionEvent e) {
				// TODO Auto-generated method stub
				int row=0;
				try {
					
					row=irz.openRoom(id,����״̬.δ����.toString());
					if(row>0){
						JOptionPane.showMessageDialog(jsp, id+"�ŷ���������");
						if(!jcb1.getSelectedItem().equals(fstate)){
							find();
						}else{
						refresh();
						}
					}
				} catch (Exception e1) {
					// TODO Auto-generated catch block
					e1.printStackTrace();
				}
			}
		});
		jb7.addActionListener(new ActionListener() {
			
			@Override
			public void actionPerformed(ActionEvent e) {
				// TODO Auto-generated method stub
				new InsertType();
			
			}
		});
		jb8.addActionListener(new ActionListener() {
			
			@Override
			public void actionPerformed(ActionEvent e) {
				// TODO Auto-generated method stub
				TypeDao td=new TypeDao();
				Vector type=new Vector<>();
				type=td.query(typeName);
				int typeId=(int) type.get(0);
				System.out.println(typeId+"zzmz");
				int row=0;
				int del=JOptionPane.showConfirmDialog(jt, "��ȷ��Ҫɾ��"+typeName+"��������з���Ϊ"+typeName+"�Ŀͷ���","����", JOptionPane.YES_NO_OPTION, JOptionPane.QUESTION_MESSAGE);
				  if(del==JOptionPane.YES_OPTION){
					  row=td.delete(typeId);
					  
				  }
				if(row>0){
					
					JOptionPane.showMessageDialog(jt, typeName+"��ɾ������������з���Ϊ"+typeName+"�Ŀͷ�");
					refresh();
				}
				
				
			}
		});
		jb9.addActionListener(new ActionListener() {
			
			@Override
			public void actionPerformed(ActionEvent e) {
				// TODO Auto-generated method stub
				new UpdateType();	
				refresh();
				
			}
		});
	jtx1.addKeyListener(new KeyListener() {
		
		@Override
		public void keyTyped(KeyEvent e) {
			// TODO Auto-generated method stub
			
		}
		
		@Override
		public void keyReleased(KeyEvent e) {
			// TODO Auto-generated method stub
			System.out.println(jtx1.getText());
			jcb1.setSelectedItem(fstate);
			jcb2.setSelectedItem(ftype);
			String id=jtx1.getText();
			try {
				
				vector=irz.vagueFind(id);
			
				
				tableModel.setDataVector(vector, title);
				
			} catch (Exception e1) {
				// TODO Auto-generated catch block
				e1.printStackTrace();
			}
		}
		
		@Override
		public void keyPressed(KeyEvent e) {
			// TODO Auto-generated method stub
			
		}
	});
	jcb1.addItemListener(new ItemListener(){

		@Override
		public void itemStateChanged(ItemEvent e) {
			jtx1.setText("");
			stateName=jcb1.getSelectedItem().toString();
			// TODO Auto-generated method stub
			if(e.getStateChange()==ItemEvent.SELECTED){
				if(!stateName.equals(fstate)&&typeName.equals(ftype)){
				
					find();
					
					
				};
				if(stateName.equals(fstate)&&typeName.equals(ftype)){
					
					try {
						vector=irz.find();
					} catch (Exception e1) {
						// TODO Auto-generated catch block
						e1.printStackTrace();
					}
					tableModel.setDataVector(vector, title);
					
				};
				if(stateName.equals(fstate)&&!typeName.equals(ftype)){
					typeName=jcb2.getSelectedItem().toString();
				
					try {
						System.out.println(typeName);
						vector=irz.typeFind(typeName);
					} catch (Exception e1) {
						// TODO Auto-generated catch block
						e1.printStackTrace();
					}
					tableModel.setDataVector(vector, title);
				}
				
			
				jb2.setEnabled(false);
				jb4.setEnabled(false);
				jb5.setEnabled(false);
				jb6.setEnabled(false);
				jb3.setEnabled(false);
				if(typeName!=(ftype)&&stateName!=(fstate)){
					
					System.out.println(typeName+"+"+stateName);
					try {
						typeName=jcb2.getSelectedItem().toString();
						stateName=jcb1.getSelectedItem().toString();
						vector=irz.find(stateName,typeName);
						tableModel.setDataVector(vector, title);
					} catch (Exception e1) {
						// TODO Auto-generated catch block
						e1.printStackTrace();
					}
					tableModel.setDataVector(vector, title);
				}	
		
			}
		}
		
		
		
	});
	jcb2.addItemListener(new ItemListener() {
		
		@Override
		public void itemStateChanged(ItemEvent e) {
			// TODO Auto-generated method stub
			jtx1.setText("");
			if(e.getStateChange()==ItemEvent.SELECTED){
				typeName=jcb2.getSelectedItem().toString();
				System.out.println(jcb2.getSelectedItem().toString()+"mmm");
				if(!typeName.equals(ftype)){
					jb8.setEnabled(true);
					jb9.setEnabled(true);
				}
				if(typeName.equals(ftype)){
					jb8.setEnabled(false);
					jb9.setEnabled(false);
				}
			
				if(typeName.equals(ftype)&&stateName!=fstate){
				
					try {
						vector=irz.find(stateName);
					} catch (Exception e1) {
						// TODO Auto-generated catch block
						e1.printStackTrace();
					}
					tableModel.setDataVector(vector, title);
					
				}else{
					try {
						typeName=jcb2.getSelectedItem().toString();
						vector=irz.typeFind(typeName);
						tableModel.setDataVector(vector, title);
					} catch (Exception e1) {
						// TODO Auto-generated catch block
						e1.printStackTrace();
					}
				}
				if(typeName!=(ftype)&&stateName!=(fstate)){
				
					System.out.println(typeName+"+"+stateName);
					try {
						typeName=jcb2.getSelectedItem().toString();
						stateName=jcb1.getSelectedItem().toString();
						vector=irz.find(stateName,typeName);
					} catch (Exception e1) {
						// TODO Auto-generated catch block
						e1.printStackTrace();
					}
					tableModel.setDataVector(vector, title);
				}
				if(stateName.equals(fstate)&&typeName.equals(ftype)){
					
					try {
						vector=irz.find();
					} catch (Exception e1) {
						// TODO Auto-generated catch block
						e1.printStackTrace();
					}
					tableModel.setDataVector(vector, title);
					
				};
				jb2.setEnabled(false);
				jb4.setEnabled(false);
				jb5.setEnabled(false);
				jb6.setEnabled(false);
				jb3.setEnabled(false);
			
		}
		}
	});

	
		
}
}
