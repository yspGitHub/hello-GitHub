package com.ssy.view;

import java.awt.CardLayout;
import java.awt.Color;
import java.awt.Container;
import java.awt.FlowLayout;
import java.awt.Font;
import java.awt.Graphics;
import java.awt.GraphicsEnvironment;
import java.awt.Image;
import java.awt.Toolkit;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.awt.event.MouseEvent;
import java.awt.event.MouseListener;
import java.io.File;
import java.io.IOException;
import java.text.SimpleDateFormat;
import java.util.Date;

import javax.imageio.ImageIO;
import javax.swing.ImageIcon;
import javax.swing.JButton;
import javax.swing.JComboBox;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JLayeredPane;
import javax.swing.JOptionPane;
import javax.swing.JPanel;
import javax.swing.JScrollPane;
import javax.swing.JTable;
import javax.swing.table.DefaultTableModel;

import com.ssy.biz.IUserInfoBiz;
import com.ssy.biz.impl.UserInfoBizImpl;
import com.ssy.entity.UserInfo;

public class Main extends Thread implements ActionListener {
	private JFrame jf = new JFrame("�Ƶ����ϵͳ");
	// ������ť�������л���Ƭ�����е�����
	private JButton jb1, jb2, jb3, jb4;
	JLayeredPane layeredPane;
	// ���干�����������
	private JPanel jp;
	private MyPanel bottomjp;
	// ���忨Ƭ���֣��ṩ��������������ʹ��
	private CardLayout card = new CardLayout();
	private JLabel jl1;
	private ImageIcon background;
	public static JLabel jl2;
	private JLabel jimage;
	Login lg = new Login(1);
	String id = lg.UserId;
	RoomPanel p1;
	CustomerPanel p2;
	UserPanel p3;
	LogPanel p4;
	JButton jb,jc;
	JLabel jlc;
	public static String nowdate;

	public Main() {
		init();
		
	}

	public Main(int i) {
	};

	/*
	 * ���߳�ˢ��ʱ�� (non-Javadoc)
	 * 
	 * @see java.lang.Thread#run()
	 */
	public void run() {

		while (true) {
			try {
				sleep(1000);
			} catch (InterruptedException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
			Date date = new Date();
			SimpleDateFormat dfm = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss");
			nowdate = dfm.format(date);

			jl2.setText(nowdate);
		}
	}

	private void init() {
		// TODO Auto-generated method stub
		layeredPane = new JLayeredPane();
		ImageIcon back = new ImageIcon("image/3.jpg");
		Main m = new Main(1);
		jp = new JPanel();
		jp.setOpaque(false);
		
		ImageIcon bc = new ImageIcon("image/b.jpg");
		bottomjp = new MyPanel(bc.getImage());
		bottomjp.setBounds(0, 0, 1200, 800);
		m.start();
		int width = (int) Toolkit.getDefaultToolkit().getScreenSize().getWidth();
		int height = (int) Toolkit.getDefaultToolkit().getScreenSize().getHeight();
		jf.setBounds((width - 1200) / 2, (height - 900) / 2, 1200, 800);
		jf.setLayout(null);

		jb1 = new JButton("�������");
		jb1.setBounds(0, 0, 300, 60);

		jb1.setFont(new Font("����", Font.TYPE1_FONT, 25));

		jb2 = new JButton("�ͻ�����");
		jb2.setBounds(300, 0, 300, 60);
		jb2.setFont(new Font("����", Font.BOLD, 25));
		jb3 = new JButton("Ա������");
		jb3.setBounds(600, 0, 300, 60);
		jb3.setFont(new Font("����", Font.BOLD, 25));
		jb4 = new JButton("��־����");
		jb4.setBounds(900, 0, 300, 60);
		jb4.setFont(new Font("����", Font.BOLD, 25));
		jl1 = new JLabel("���ţ�" + id);
		jl1.setBounds(20, 720, 200, 30);
		jl1.setForeground(Color.blue);
		jl1.setFont(new Font("����", Font.BOLD, 20));
		jb = new JButton("ע��");
		jb.setFont(new Font("����", Font.BOLD, 20));
		jb.setBackground(Color.red);
		jb.setFocusPainted(false);
		jb.setOpaque(false);
		jb.setBounds(220, 720, 90, 30);
		jc = new JButton("��������");
		jc.setFont(new Font("����", Font.BOLD, 20));
		jc.setBackground(Color.red);
		jc.setFocusPainted(false);
		jc.setOpaque(false);
		jc.setBounds(330, 720, 120, 30);
		jl2 = new JLabel();
		jl2.setForeground(Color.blue);
		jl2.setBounds(950, 720, 300, 30);
		jl2.setFont(new Font("����", Font.BOLD, 20));

		jb1.addActionListener(this);
		jb1.setBackground(Color.white);
		jb1.setOpaque(false);
		jb1.setForeground(Color.black);

		jb1.setFocusPainted(false);
		jb2.addActionListener(this);
		jb2.setBackground(Color.white);
		jb2.setOpaque(false);
		jb2.setFocusPainted(false);
		jb2.setForeground(Color.white);
		jb3.addActionListener(this);
		jb3.setBackground(Color.white);
		jb3.setOpaque(false);
		jb3.setFocusPainted(false);
		jb3.setForeground(Color.white);
		jb4.addActionListener(this);
		jb4.setBackground(Color.white);
		jb4.setOpaque(false);
		jb4.setFocusPainted(false);
		jb4.setForeground(Color.white);
		jp.setBounds(20, 70, 1200, 600);
		jp.setLayout(card);// ���ò���
		p1 = new RoomPanel();
		p2 = new CustomerPanel();
		p3 = new UserPanel();
		p4 = new LogPanel();
		p1.setBounds(0, 100, 1200, 600);
		p2.setBounds(0, 100, 1200, 600);
		p3.setBounds(0, 100, 1200, 600);
		p4.setBounds(0, 100, 1200, 600);
		jp.add(p1, "one");
		jp.add(p2, "second");
		jp.add(p3, "third");
		jp.add(p4, "forth");

		ImageIcon icon = new ImageIcon("image/timg.jpg");

		jf.setIconImage(icon.getImage());
		jf.setVisible(true);

		layeredPane.add(bottomjp, JLayeredPane.DEFAULT_LAYER);
		layeredPane.add(jp, JLayeredPane.MODAL_LAYER);
		layeredPane.add(jb1, JLayeredPane.MODAL_LAYER);
		layeredPane.add(jb2, JLayeredPane.MODAL_LAYER);
		layeredPane.add(jb3, JLayeredPane.MODAL_LAYER);
		layeredPane.add(jb4, JLayeredPane.MODAL_LAYER);
		//layeredPane.add(jc, JLayeredPane.MODAL_LAYER);
		layeredPane.add(jl1, JLayeredPane.MODAL_LAYER);
		layeredPane.add(jb, JLayeredPane.MODAL_LAYER);
		layeredPane.add(jl2, JLayeredPane.MODAL_LAYER);
		jf.setLayeredPane(layeredPane);
		jb.addActionListener(new ActionListener() {
			@Override
			public void actionPerformed(ActionEvent e) {
				// TODO Auto811-generated method stub
				int del = JOptionPane.showConfirmDialog(jp, "��ȷ��Ҫע����", "����", JOptionPane.YES_NO_OPTION,
						JOptionPane.QUESTION_MESSAGE);
				if (del == JOptionPane.YES_OPTION) {
					System.out.println(1);
					new Login();
					jf.dispose();
				}
			}
		});
	}

	@Override
	public void actionPerformed(ActionEvent e) {
		// TODO Auto-generated method stub
		if (e.getSource() == jb1) {
			// ImageIcon icon=new ImageIcon("image/4.jpg");
			// jb1.setIcon(icon);

			jb1.setForeground(Color.black);
			jb2.setForeground(Color.white);
			jb3.setForeground(Color.white);
			jb4.setForeground(Color.white);
			card.show(jp, "one");
			new CustomerPanel();
		} else if (e.getSource() == jb2) {

			jb1.setForeground(Color.white);
			jb2.setForeground(Color.black);
			jb3.setForeground(Color.white);
			jb4.setForeground(Color.white);
			card.show(jp, "second");
		} else if (e.getSource() == jb3) {

			jb1.setForeground(Color.white);
			jb2.setForeground(Color.white);
			jb3.setForeground(Color.black);
			jb4.setForeground(Color.white);
			card.show(jp, "third");
		} else if (e.getSource() == jb4) {

			jb1.setForeground(Color.white);
			jb2.setForeground(Color.white);
			jb3.setForeground(Color.white);
			jb4.setForeground(Color.black);
			card.show(jp, "forth");
			p4 = new LogPanel();
		}
	}

}
