package com.ssy.view;

import java.awt.Color;
import java.awt.Font;
import java.awt.Toolkit;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.awt.event.FocusEvent;
import java.awt.event.FocusListener;
import java.awt.event.ItemEvent;
import java.awt.event.ItemListener;
import java.util.Vector;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

import javax.swing.ImageIcon;
import javax.swing.JButton;
import javax.swing.JComboBox;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JLayeredPane;
import javax.swing.JOptionPane;
import javax.swing.JPanel;
import javax.swing.JTextField;
import javax.swing.text.StyledEditorKit.BoldAction;

import com.ssy.dao.IRoomDao;
import com.ssy.dao.TypeDao;
import com.ssy.dao.impl.RoomDaoImpl;
import com.ssy.entity.Room;


public class InsertRoom {
	private static final String ItemListener = null;
	private JFrame jf;
	private JButton jb1;
	private JLabel jl1,jlm;
	private JLabel jl2;
	private JLabel jl3;
	private JLabel jl4;
	ImageIcon nicon=new ImageIcon("image/no.png");
	ImageIcon oicon=new ImageIcon("image/ok.png");
	private boolean flag;
	private JTextField jtf1;
	private JComboBox jcb2;
	private JComboBox jcb1;
	private JComboBox jcb3;
	private JLayeredPane layeredPane=new JLayeredPane();
	private JPanel buttomJp;
	private int typeInt;
	TypeDao td=new TypeDao();
	public InsertRoom(){
		init();
	}
	public void init(){
		jf=new JFrame("��������");
		int width = (int)Toolkit.getDefaultToolkit().getScreenSize().getWidth();
		int height = (int)Toolkit.getDefaultToolkit().getScreenSize().getHeight();
		jf.setBounds((width-360)/2, (height-360)/2, 320, 300);
		jf.setLayout(null);
	//	jf.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		jf.setVisible(true);
		jl1=new JLabel("����:");
		jl1.setBounds(20,10,60,30);
		jl1.setFont(new Font("����", Font.BOLD, 16));//���������С
		jtf1=new JTextField();
		jtf1.setBounds(90, 10, 180, 30);
		jtf1.setFont(new Font("����",Font.BOLD,16));
		jtf1.setBackground(new Color(149, 192, 247));
		jlm=new JLabel();
		jlm.setBounds(280, 18, 16, 16);
		jl2=new JLabel("¥��:");
		jl2.setBounds(20,60,60,30);
		jl2.setFont(new Font("����", Font.BOLD, 16));
		
		jcb1=new JComboBox<>();	
		jcb1.setBounds(90, 60, 180, 30);
		for(int i=1;i<30;i++){
			jcb1.addItem(i);
		}
		jl3=new JLabel("����:");
		jl3.setBounds(20,110,60,30);
		jl3.setFont(new Font("����", Font.BOLD, 16));
		jcb2=new JComboBox<>();	
		jcb2.setBounds(90, 110, 180, 30);
		jcb2.addItemListener(new ItemListener(){

			@Override
			public void itemStateChanged(ItemEvent e) {
				// TODO Auto-generated method stub
				if(e.getStateChange()==ItemEvent.SELECTED){
					Vector vt2=new Vector();
					System.out.println(jcb2.getSelectedItem().toString());
					try {
						vt2=td.query(jcb2.getSelectedItem().toString());
					} catch (Exception e1) {
						// TODO Auto-generated catch block
						e1.printStackTrace();
					}
					typeInt=(int) vt2.get(0);
					System.out.println(typeInt);
				}
			
				
			}
			
			
		});
		
		
		try {
			Vector<Vector> types=new Vector<Vector>();
			types=td.find();
			for(Vector type:types){
				
				jcb2.addItem(type.get(1));
				
			}
			
		
			
		} catch (Exception e) {
			// TODO: handle exception
			e.printStackTrace();
		}
		
		//jl4=new JLabel("״̬:");
		//jl4.setBounds(20,160,60,30);
		//jl4.setFont(new Font("����", Font.BOLD, 16));
		jcb3=new JComboBox<>();	
		
		jcb3.setBounds(90, 160, 180, 30);
		jcb3.addItem("δ����");
		jcb3.addItem("������");
		jcb3.addItem("������");
		jb1=new JButton("����");
		jb1.setBounds(110,210,120,40);
		jb1.setFont(new Font("����", Font.BOLD, 20));
		jb1.setBackground(Color.white);
		jb1.setOpaque(false);
		jb1.addActionListener(new ActionListener() {
			IRoomDao rd=new RoomDaoImpl();
			@Override
			public void actionPerformed(ActionEvent e) {
				// TODO Auto-generated method stub
				Room room=new Room(); 
				
				room.setId(jtf1.getText().toString());
				System.out.println("���ţ�"+jtf1.getText());
				room.setFlower(Integer.parseInt(jcb1.getSelectedItem().toString()));
				System.out.println("¥�㣺"+Integer.parseInt(jcb1.getSelectedItem().toString()));
				room.setType(typeInt);
			
				room.setSate("δ����");
				room.setTel(8888+Integer.parseInt(jtf1.getText().toString()));
				int row=0;
						try {
							if(flag){
							row=rd.insert(room);
							}else{
								JOptionPane.showMessageDialog(jb1, "����ֻ��Ϊ3λ����");
							}
					
						
							if(row>0){
								JOptionPane.showMessageDialog(jb1, "�ͷ�ע��ɹ���");
								jf.dispose();
							}else{
								JOptionPane.showMessageDialog(jb1, "�ͷ�ע��ʧ�ܣ�");
							}
							
							
						} catch (Exception e2) {
							// TODO: handle exception
							e2.printStackTrace();;
						}
			}
		});
		jtf1.addFocusListener(new FocusListener() {
			
			@Override
			public void focusLost(FocusEvent e) {
				// TODO Auto-generated method stub
				String idc=String.valueOf(jtf1.getText());	
				
				Pattern p1=Pattern.compile("[0-9]{3}");
				Matcher m1=p1.matcher(idc);
				flag=m1.matches();
				if(!flag){
					jlm.setIcon(nicon);
				}else{
					jlm.setIcon(oicon);
				}
			}
			
			@Override
			public void focusGained(FocusEvent e) {
				// TODO Auto-generated method stub
				
			}
		});
		layeredPane.add(jl1, JLayeredPane.MODAL_LAYER);
		layeredPane.add(jtf1, JLayeredPane.MODAL_LAYER);
		layeredPane.add(jl2, JLayeredPane.MODAL_LAYER);
		layeredPane.add(jcb1, JLayeredPane.MODAL_LAYER);
		layeredPane.add(jl3, JLayeredPane.MODAL_LAYER);
		layeredPane.add(jcb2, JLayeredPane.MODAL_LAYER);
		layeredPane.add(jlm, JLayeredPane.MODAL_LAYER);
		layeredPane.add(jb1, JLayeredPane.MODAL_LAYER);
		ImageIcon bc = new ImageIcon("image/b.jpg");
		buttomJp = new MyPanel(bc.getImage());
		buttomJp.setBounds(0, 0, 320, 260);
		layeredPane.add(buttomJp, JLayeredPane.DEFAULT_LAYER);	
		jf.setLayeredPane(layeredPane);
		jf.setVisible(true);
//		jf.add(jl1);
//		jf.add(jtf1);
//		jf.add(jl2);
//		jf.add(jcb1);
//		jf.add(jl3);
//		jf.add(jcb2);
//		//jf.add(jl4);
//		//jf.add(jcb3);
//		jf.add(jb1);
		ImageIcon icon = new ImageIcon("image/timg.jpg");
		//��ʾ����ͼ��
		jf.setIconImage(icon.getImage());
		
	}
}
