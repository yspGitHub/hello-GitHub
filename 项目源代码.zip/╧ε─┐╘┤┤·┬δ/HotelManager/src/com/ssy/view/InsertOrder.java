package com.ssy.view;

import java.awt.Font;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.util.Calendar;
import java.util.TimeZone;

import javax.swing.JButton;
import javax.swing.JComboBox;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JTextField;

import com.ssy.dao.TypeDao;
import com.ssy.entity.Type;

public class InsertOrder {
	private JFrame jf;
	private JLabel jl1;
	private JLabel jl2,jl3,jl4;
	private JTextField jtf1;
	private JComboBox jcb1,jcb2,jcb3,jcb4,jcb5;
	private JTextField jtf2,jtf3;
	private JButton jb1;
	public InsertOrder(){
		init();
	}
	private void init() {
		// TODO Auto-generated method stub
		jf=new JFrame("����ԤԼ");
		jf.setBounds(400, 100, 500, 400);
		jf.setLayout(null);
		jf.setVisible(true);
		jl1=new JLabel("����:");
		jl1.setBounds(20,10,60,30);
		jl1.setFont(new Font("����", Font.BOLD, 16));//���������С
		jtf1=new JTextField();
		jtf1.setBounds(90, 10, 180, 30);
		jtf1.setFont(new Font("����",Font.BOLD,16));
		jl2=new JLabel("�绰:");
		jl2.setBounds(20,50,60,30);
		jl2.setFont(new Font("����", Font.BOLD, 16));//���������С
		jtf2=new JTextField();
		jtf2.setBounds(90, 50, 180, 30);
		jtf2.setFont(new Font("����",Font.BOLD,16));
		jl3=new JLabel("����:");
		jl3.setBounds(20,90,60,30);
		jl3.setFont(new Font("����", Font.BOLD, 16));
		jcb1=new JComboBox();
		jcb1.setBounds(90, 90, 180, 30);
		jl4=new JLabel("ʱ��:");
		jl4.setFont(new Font("����", Font.BOLD, 16));
		jl4.setBounds(20,130,60,30); 
		
		jcb2=new JComboBox();
		jcb2.setBounds(90, 130, 60, 30);
		Calendar cld=Calendar.getInstance(TimeZone.getTimeZone("GMT+08:00"));
		int year=cld.get(Calendar.YEAR);
		int month = cld.get(Calendar.MONTH) + 1;   //��ȡ�·ݣ�0��ʾ1�·�
		int day = cld.get(Calendar.DAY_OF_MONTH);
		int hour = cld.get(Calendar.HOUR_OF_DAY);
		int last = cld.getActualMaximum(cld.DAY_OF_MONTH);
		
		jcb2.setSelectedItem(year);
		
		for(int i=2017;i<2100;i++){
			jcb2.addItem(i);
		}
		
		jcb3=new JComboBox();
		jcb3.setSelectedItem(month);
		for(int i=1;i<13;i++){
			jcb3.addItem(i);
		}
		jcb3.setBounds(180, 130, 50, 30);
		
		jcb4=new JComboBox();
		System.out.println(last);
		for(int i=1;i<last+1;i++){
			jcb4.addItem(i);
		}
		jcb4.setBounds(270, 130, 50, 30);
		jcb5=new JComboBox();
		for(int i=1;i<25;i++){
			jcb5.addItem(i);
		}
		jcb5.setBounds(360, 130, 50, 30);
		jb1=new JButton("����");
		jb1.setBounds(210,310,80,30);
		jf.add(jl1);
		jf.add(jtf1);
		jf.add(jl2);
		jf.add(jtf2);
		
		jf.add(jl3);
		jf.add(jl4);
		
		jf.add(jcb1);
		jf.add(jcb2);
		jf.add(jcb3);
		jf.add(jcb4);
		jf.add(jcb5);
		jf.add(jb1);
		
		jb1.addActionListener(new ActionListener() {

			@Override
			public void actionPerformed(ActionEvent e) {
				// TODO Auto-generated method stub
		
			}
			
			
		});
	}
}
