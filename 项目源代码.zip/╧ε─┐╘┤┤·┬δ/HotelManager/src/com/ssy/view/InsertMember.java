package com.ssy.view;

import java.awt.Color;
import java.awt.Font;
import java.awt.Toolkit;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.awt.event.FocusEvent;
import java.awt.event.FocusListener;
import java.awt.event.ItemEvent;
import java.awt.event.ItemListener;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

import javax.swing.ImageIcon;
import javax.swing.JButton;
import javax.swing.JComboBox;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JLayeredPane;
import javax.swing.JOptionPane;
import javax.swing.JPanel;
import javax.swing.JTextField;

import com.ssy.biz.IRoomBiz;
import com.ssy.biz.impl.RoomBizImpl;
import com.ssy.dao.MemberDao;
import com.ssy.dao.TypeDao;
import com.ssy.entity.Member;
import com.ssy.entity.Type;
import com.ssy.entity.Vip;

public class InsertMember {
	private JFrame jf;
	private JLabel jl1,jl2,jl3,jl4,jlm,jln,jlh;
	private JTextField jtf1,jtf2,jtf3;
	private JButton jb1;
	private JComboBox jcb1;
	private JLayeredPane layeredPane=new JLayeredPane();
	private JPanel buttomJp;
	private String idCard,name;
	ImageIcon nicon=new ImageIcon("image/no.png");
	ImageIcon oicon=new ImageIcon("image/ok.png");
	private int vipId;
	private boolean fg1,fg2,fg3;
	private String tel;
	public InsertMember(){
		init();
	}

	private void init() {
		// TODO Auto-generated method stub
		// TODO Auto-generated method stub
		jf=new JFrame("������Ա");
		int width = (int)Toolkit.getDefaultToolkit().getScreenSize().getWidth();
		int height = (int)Toolkit.getDefaultToolkit().getScreenSize().getHeight();
		jf.setBounds((width-300)/2, (height-260)/2, 320, 260);
	
		jf.setLayout(null);
	
		jl1=new JLabel("����:");
		jl1.setBounds(20,10,60,30);
		jl1.setFont(new Font("����", Font.BOLD, 16));//���������С
		
		jtf1=new JTextField();
		jtf1.setBounds(90, 10, 180, 30);
		jtf1.setFont(new Font("����",Font.BOLD,16));
		jtf1.setBackground(new Color(149, 192, 247));
		jlm=new JLabel();
		jlm.setBounds(280, 18, 16, 16);
		jl2=new JLabel("����֤:");
		jl2.setBounds(20,50,60,30);
		jl2.setFont(new Font("����", Font.BOLD, 16));//���������С
		
		jtf2=new JTextField();
		jtf2.setBounds(90, 50, 180, 30);
		jtf2.setFont(new Font("����",Font.BOLD,16));
		jtf2.setBackground(new Color(149, 192, 247));
		jln=new JLabel();
		jln.setBounds(280, 58, 16, 16);
		jl3=new JLabel("�绰:");
		jl3.setBounds(20,90,60,30);
		jl3.setFont(new Font("����", Font.BOLD, 16));//���������С
		jtf3=new JTextField();
		jtf3.setBounds(90, 90, 180, 30);
		jtf3.setFont(new Font("����",Font.BOLD,16));
		jtf3.setBackground(new Color(149, 192, 247));
		jlh=new JLabel();
		jlh.setBounds(280, 98, 16, 16);
		jb1=new JButton("����");
		jb1.setBounds(110,180,120,40);
		jb1.setBackground(Color.red);
		jb1.setOpaque(false);
		jl4=new JLabel("����:");
		jl4.setBounds(20,130,60,30);
		jl4.setFont(new Font("����", Font.BOLD, 16));//���������С
		jcb1=new JComboBox();
		jb1.setFont(new Font("����", Font.BOLD, 20));
		jcb1.addItem("��ͨ��Ա");
		jcb1.addItem("�ƽ��Ա");
		jcb1.addItem("�׽��Ա");
		jcb1.setBounds(90,130,180,30);
	

		vipId=jcb1.getSelectedIndex()+1;
		System.out.println(vipId);
		
		layeredPane.add(jl4, JLayeredPane.MODAL_LAYER);
		layeredPane.add(jcb1, JLayeredPane.MODAL_LAYER);
		layeredPane.add(jb1, JLayeredPane.MODAL_LAYER);
		layeredPane.add(jl1, JLayeredPane.MODAL_LAYER);
		layeredPane.add(jtf1, JLayeredPane.MODAL_LAYER);
		layeredPane.add(jl2, JLayeredPane.MODAL_LAYER);
		layeredPane.add(jtf2, JLayeredPane.MODAL_LAYER);
		layeredPane.add(jl3, JLayeredPane.MODAL_LAYER);
		layeredPane.add(jtf3, JLayeredPane.MODAL_LAYER);
		layeredPane.add(jlm, JLayeredPane.MODAL_LAYER);
		layeredPane.add(jln, JLayeredPane.MODAL_LAYER);
		layeredPane.add(jlh, JLayeredPane.MODAL_LAYER);
		ImageIcon bc = new ImageIcon("image/b.jpg");
		buttomJp = new MyPanel(bc.getImage());
		buttomJp.setBounds(0, 0, 320, 500);
		layeredPane.add(buttomJp, JLayeredPane.DEFAULT_LAYER);	
		jf.setLayeredPane(layeredPane);
		jf.setVisible(true);
		IRoomBiz irz=new  RoomBizImpl();
//		jf.add(jl1);
//		jf.add(jtf1);
//		jf.add(jl2);
//		jf.add(jtf2);
//		jf.add(jl3);
//		jf.add(jtf3);
//		jf.add(jl4);
//		jf.add(jcb1);
//		jf.add(jb1);
		ImageIcon icon = new ImageIcon("image/timg.jpg");
		//��ʾ����ͼ��
		jf.setIconImage(icon.getImage());
		
		jb1.addActionListener(new ActionListener() {

			@Override
			public void actionPerformed(ActionEvent e) {
				// TODO Auto-generated method stub
				idCard=jtf2.getText();
				name=jtf1.getText();
				tel=jtf3.getText();
					MemberDao md=new MemberDao();
					Vip vip=new Vip();
					vip.setId(vipId);
					Member member=new Member();
					member.setId(idCard);
					member.setName(name);
					member.setTel(tel);
					member.setVip(vip);
					int row=0;
					if(fg1&&fg2&&fg3){
					row=md.insert(member);
					}
					if(row>0){
					
						JOptionPane.showMessageDialog(jb1, "��Աע��ɹ���");
						jf.dispose();
					}else{
						JOptionPane.showMessageDialog(jb1, "��Աע��ʧ�ܣ�");
					}
			}
			
			
		});
		jtf1.addFocusListener(new FocusListener() {
			
			@Override
			public void focusLost(FocusEvent e) {
				// TODO Auto-generated method stub
				String idc=String.valueOf(jtf1.getText());	
				
				Pattern p1=Pattern.compile("[\u4E00-\u9FA5]{2,5}");
				Matcher m1=p1.matcher(idc);
				fg1=m1.matches();
				if(!fg1){
					jlm.setIcon(nicon);
				}else{
					jlm.setIcon(oicon);
				}
			}
			
			@Override
			public void focusGained(FocusEvent e) {
				// TODO Auto-generated method stub
				
			}
		});
		jtf2.addFocusListener(new FocusListener() {
			
			@Override
			public void focusLost(FocusEvent e) {
				// TODO Auto-generated method stub
				String idc=String.valueOf(jtf2.getText());	
				
				Pattern p1=Pattern.compile("[0-9]{17}[0-9a-zA-Z]{1}");
				Matcher m1=p1.matcher(idc);
				fg2=m1.matches();
				if(!fg2){
					jln.setIcon(nicon);
				}else{
					jln.setIcon(oicon);
				}
			}
			
			@Override
			public void focusGained(FocusEvent e) {
				// TODO Auto-generated method stub
				
			}
		});
		jtf3.addFocusListener(new FocusListener() {
			
			@Override
			public void focusLost(FocusEvent e) {
				// TODO Auto-generated method stub
				String idc=String.valueOf(jtf3.getText());	
				
				Pattern p1=Pattern.compile("[0-9]{11}");
				Matcher m1=p1.matcher(idc);
				fg2=m1.matches();
				if(!fg2){
					jlh.setIcon(nicon);
				}else{
					jlh.setIcon(oicon);
				}
			}
			
			@Override
			public void focusGained(FocusEvent e) {
				// TODO Auto-generated method stub
				
			}
		});
		jcb1.addItemListener(new ItemListener() {
			
			@Override
			public void itemStateChanged(ItemEvent e) {
				// TODO Auto-generated method stub
				if(e.getStateChange()==ItemEvent.SELECTED){
				vipId=jcb1.getSelectedIndex()+1;
				System.out.println(vipId);
				}
			}
		});
	}

}
