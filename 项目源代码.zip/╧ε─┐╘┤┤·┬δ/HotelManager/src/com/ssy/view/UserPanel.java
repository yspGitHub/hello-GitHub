package com.ssy.view;

import java.awt.Color;
import java.awt.Component;
import java.awt.Dimension;
import java.awt.Font;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.awt.event.KeyEvent;
import java.awt.event.KeyListener;
import java.awt.event.MouseEvent;
import java.awt.event.MouseListener;
import java.util.Vector;

import javax.swing.JButton;
import javax.swing.JComboBox;
import javax.swing.JLabel;
import javax.swing.JLayeredPane;
import javax.swing.JOptionPane;
import javax.swing.JPanel;
import javax.swing.JScrollPane;
import javax.swing.JTable;
import javax.swing.JTextField;
import javax.swing.SwingConstants;
import javax.swing.table.DefaultTableCellRenderer;
import javax.swing.table.DefaultTableModel;
import javax.swing.table.JTableHeader;
import javax.swing.table.TableCellRenderer;

import com.ssy.biz.IUserInfoBiz;
import com.ssy.biz.impl.UserInfoBizImpl;

public class UserPanel extends JPanel {
	private JButton jb1, jb2, jb3, jb4, jb5, jb6, jb7, jb8, jb9,jba;
	private JComboBox jcb1, jcb2, jcb3, jcb4, jcb5;
	private JLabel jl1;
	private JLabel jl2;
	private JTextField jtx1;
	public static String id;
	IUserInfoBiz iiz = new UserInfoBizImpl();
	DefaultTableModel tableModel = new DefaultTableModel();
	JScrollPane jsp;
	JLayeredPane jp;
	private String auth;
	Login lg = new Login(11);
	private Vector title;
	private JTable jt;
	Vector<Vector> vector;

	public UserPanel() {
		init();
	}

	public UserPanel(int i) {

	}

	public void initFind() {
		this.setBackground(Color.white);
		vector = new Vector<Vector>();
		title = new Vector();
		title.add("����");
		title.add("����");
		title.add("��ַ");

		title.add("�绰");
		title.add("Ȩ��");

		try {
			System.out.println(vector.size());
			vector = iiz.seek();
			System.out.println(vector.size() + "mmmmmm");
		} catch (Exception e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		tableModel.setDataVector(vector, title);
	}

	private void init() {
		this.setOpaque(false);
		// TODO Auto-generated method stub
		jt = new JTable() {
			public boolean isCellEditable(int row, int column) {
				return false;
			}
		};
		jt.setModel(tableModel);
		jt.validate();
		jt.getTableHeader().setReorderingAllowed(false);
		jsp = new JScrollPane(jt);
		jsp.setBounds(10, 80, 930, 400);
		jt.setFont(new Font("����", Font.BOLD, 20));
		jt.setRowHeight(25);
		jt.getTableHeader().setFont(new Font("����", Font.TRUETYPE_FONT, 20));
		this.setBounds(0, 0, 900, 400);
		jb1 = new JButton("ע��Ա��");
		jb1.setBounds(1000, 80, 120, 40);
		jb1.setEnabled(false);
		jb1.setBackground(Color.white);
		jb1.setOpaque(false);
		jb1.setForeground(Color.black);
		jb1.setFont(new Font("����", Font.BOLD, 20));
		jb1.setFocusPainted(false);
		jb2 = new JButton("ɾ��Ա��");
		jb2.setBounds(1000, 170, 120, 40);
		jb2.setEnabled(false);
		jb2.setBackground(Color.white);
		jb2.setOpaque(false);
		jb2.setForeground(Color.black);
		jb2.setFont(new Font("����", Font.BOLD, 20));
		jb2.setFocusPainted(false);
		jb3 = new JButton("�޸�����");
		jb3.setBounds(1000, 350, 120, 40);
		jb3.setBackground(Color.white);
		jb3.setOpaque(false);
		jb3.setForeground(Color.black);
		jb3.setFont(new Font("����", Font.BOLD, 20));
		jb3.setFocusPainted(false);
		jb4 = new JButton("�޸�Ա��");
		jb4.setBounds(1000, 260, 120, 40);
		jb4.setBackground(Color.white);
		jb4.setOpaque(false);
		jb4.setForeground(Color.black);
		jb4.setFont(new Font("����", Font.BOLD, 20));
		jb4.setFocusPainted(false);
		jb4.setEnabled(false);
		jba=new JButton("ˢ��");
		jba.setBounds(1000, 30, 120, 40);
		jba.setBackground(Color.white);
		jba.setOpaque(false);
		jba.setForeground(Color.black);
		jba.setFont(new Font("����", Font.BOLD, 20));
		jba.setFocusPainted(false);
		
		DefaultTableCellRenderer render = new DefaultTableCellRenderer() {
			public Component getTableCellRendererComponent(JTable table, Object value, boolean isSelected,
					boolean hasFocus, int row, int column) {
				setOpaque(false);
				jt.setSelectionForeground(Color.black);
				if (isSelected) {
					if (row == jt.getSelectedRow()) {
						setOpaque(true);
						jt.setSelectionForeground(Color.white);

					}
				}

				return super.getTableCellRendererComponent(jt, value, true, false, row, column);
			}
		};
		jt.setSelectionBackground(new Color(149, 192, 247));

		render.setOpaque(false);

		jt.setDefaultRenderer(Object.class, render);

		jt.getTableHeader().setReorderingAllowed(false);
		jt.setModel(tableModel);
		jt.validate();
		jt.setOpaque(false);
		jsp.setOpaque(false);

		jsp.getViewport().setOpaque(false);// ��JScrollPane����Ϊ͸��
		jsp.setOpaque(false);// ���м��viewport����Ϊ͸��
		jsp.setViewportView(jt);// װ�ر���
		jsp.setColumnHeaderView(jt.getTableHeader());// ����ͷ����HeaderView���֣�
		jsp.getColumnHeader().setOpaque(false);// ��ȡ��ͷ����������Ϊ͸��

		jt.getTableHeader().setReorderingAllowed(false);
		jt.setDefaultRenderer(Object.class, render);

		JTableHeader header = jt.getTableHeader();// ��ȡͷ��
		header.setPreferredSize(new Dimension(30, 26));
		header.setOpaque(false);// ����ͷ��Ϊ͸��
		header.getTable().setOpaque(false);// ����ͷ������ı���͸��
		header.setDefaultRenderer(new HeaderCellRenderer());
		TableCellRenderer headerRenderer = header.getDefaultRenderer();
		if (headerRenderer instanceof JLabel) {
			((JLabel) headerRenderer).setHorizontalAlignment(JLabel.CENTER);
			((JLabel) headerRenderer).setOpaque(false);
		}

		if (lg.Authority == 1) {
			jb1.setEnabled(true);
		}
		jl1 = new JLabel("��ѯ:");
		jl1.setBounds(12, 20, 90, 20);
		jl1.setFont(new Font("����", Font.BOLD, 20));
		jtx1 = new JTextField();
		jtx1.setBounds(65, 16, 150, 30);
		jtx1.setOpaque(false);
		initFind();
		this.setLayout(null);

		this.add(jtx1);
		this.add(jsp);
		this.add(jb1);
		this.add(jb2);
		this.add(jb3);
		this.add(jl1);
		this.add(jb4);
		this.add(jba);
		jb1.addActionListener(new ActionListener() {

			@Override
			public void actionPerformed(ActionEvent e) {
				// TODO Auto-generated method stub
				new InsertUser();
			}
		});

		jb2.addActionListener(new ActionListener() {

			@Override
			public void actionPerformed(ActionEvent e) {
				// TODO Auto-generated method stub
				int del = JOptionPane.showConfirmDialog(jb2, "��ȷ��Ҫɾ��" + id + "��Ա����", "����", JOptionPane.YES_NO_OPTION,
						JOptionPane.QUESTION_MESSAGE);
				if (del == JOptionPane.YES_OPTION) {
					int row = iiz.delete(id);
					initFind();
				} else {
					return;
				}

			}
		});
		jb3.addActionListener(new ActionListener() {

			@Override
			public void actionPerformed(ActionEvent e) {
				// TODO Auto-generated method stub
				new UpdateUserPassword();
			}
		});
		jb4.addActionListener(new ActionListener() {
			
			@Override
			public void actionPerformed(ActionEvent e) {
				// TODO Auto-generated method stub
				new UpdateUser();
			}
		});
		jba.addActionListener(new ActionListener() {
			
			@Override
			public void actionPerformed(ActionEvent e) {
				// TODO Auto-generated method stub
				initFind();
				jtx1.setText("");
				
			}
		});
		jt.addMouseListener(new MouseListener() {

			@Override
			public void mouseReleased(MouseEvent e) {
				// TODO Auto-generated method stub
				int row = jt.getSelectedRow();
				id = jt.getValueAt(row, 0).toString();
				if (lg.Authority == 1) {
					jb2.setEnabled(true);
					jb1.setEnabled(true);
					jb4.setEnabled(true);
				}

				System.out.println(id);
			}

			@Override
			public void mousePressed(MouseEvent e) {
				// TODO Auto-generated method stub

			}

			@Override
			public void mouseExited(MouseEvent e) {
				// TODO Auto-generated method stub

			}

			@Override
			public void mouseEntered(MouseEvent e) {
				// TODO Auto-generated method stub

			}

			@Override
			public void mouseClicked(MouseEvent e) {
				// TODO Auto-generated method stub

			}
		});
		jtx1.addKeyListener(new KeyListener() {

			@Override
			public void keyTyped(KeyEvent e) {
				// TODO Auto-generated method stub

			}

			@Override
			public void keyReleased(KeyEvent e) {
				// TODO Auto-generated method stub
				String info = jtx1.getText();
				vector = new Vector<Vector>();

				title = new Vector();
				title.add("����");
				title.add("����");
				title.add("��ַ");

				title.add("�绰");
				title.add("Ȩ��");

				try {
					System.out.println(vector.size());
					vector = iiz.mfind(info);
				} catch (Exception e1) {
					// TODO Auto-generated catch block
					e1.printStackTrace();
				}
				tableModel.setDataVector(vector, title);

			}

			@Override
			public void keyPressed(KeyEvent e) {
				// TODO Auto-generated method stub

			}
		});

		this.setVisible(true);
	}
}
