package com.ssy.view;

import java.awt.Color;
import java.awt.Font;
import java.awt.Toolkit;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.awt.event.FocusEvent;
import java.awt.event.FocusListener;
import java.util.Vector;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

import javax.swing.ImageIcon;
import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JLayeredPane;
import javax.swing.JOptionPane;
import javax.swing.JPanel;
import javax.swing.JTextField;

import com.ssy.dao.TypeDao;
import com.ssy.entity.Type;


public class UpdateType {
	private JFrame jf;
	private JLabel jl1;
	
	private boolean fg1,fg2;
	public static boolean flag=false;
	private JLabel jl2,jlm,jln;
	private JTextField jtf1;
	ImageIcon nicon=new ImageIcon("image/no.png");
	ImageIcon oicon=new ImageIcon("image/ok.png");
	private JTextField jtf2;
	private JLayeredPane layeredPane=new JLayeredPane();
	private JPanel buttomJp;
	private JButton jb1;
	RoomPanel rp=new RoomPanel(1);

	public UpdateType(){
		init();
	}
	public UpdateType(int i){
		
	}
	
	private void init() {
		// TODO Auto-generated method stub
		
		jf=new JFrame("�޸ķ���");
		int width = (int)Toolkit.getDefaultToolkit().getScreenSize().getWidth();
		int height = (int)Toolkit.getDefaultToolkit().getScreenSize().getHeight();
		jf.setBounds((width-360)/2, (height-360)/2, 320, 200);
		jf.setLayout(null);
		jf.setVisible(true);
		jl1=new JLabel("����:");
		jl1.setBounds(20,10,60,30);
		jl1.setFont(new Font("����", Font.BOLD, 16));//���������С
		jtf1=new JTextField();
		jtf1.setBounds(90, 10, 180, 30);
		jtf1.setFont(new Font("����",Font.BOLD,16));
		jtf1.setBackground(new Color(149, 192, 247));
		jlm=new JLabel();
		jlm.setBounds(280, 18, 16, 16);
		jl2=new JLabel("�۸�:");
		jl2.setBounds(20,50,60,30);
		jl2.setFont(new Font("����", Font.BOLD, 16));//���������С
		jtf2=new JTextField();
		jtf2.setBounds(90, 50, 180, 30);
		jtf2.setBackground(new Color(149, 192, 247));
		jtf2.setFont(new Font("����",Font.BOLD,16));
		jln=new JLabel();
		jln.setBounds(280, 68, 16, 16);
		jb1=new JButton("�޸�");
		jb1.setBounds(110,110,120,40);
		jb1.setBackground(Color.white);
		jb1.setOpaque(false);
		jb1.setFont(new Font("����", Font.BOLD, 20));
		layeredPane.add(jl1, JLayeredPane.MODAL_LAYER);
		layeredPane.add(jtf1, JLayeredPane.MODAL_LAYER);
		layeredPane.add(jl2, JLayeredPane.MODAL_LAYER);
		layeredPane.add(jtf2, JLayeredPane.MODAL_LAYER);
		layeredPane.add(jb1, JLayeredPane.MODAL_LAYER);
		layeredPane.add(jlm, JLayeredPane.MODAL_LAYER);
		layeredPane.add(jln, JLayeredPane.MODAL_LAYER);
		ImageIcon bc = new ImageIcon("image/b.jpg");
		buttomJp = new MyPanel(bc.getImage());
		buttomJp.setBounds(0, 0, 320, 260);
		layeredPane.add(buttomJp, JLayeredPane.DEFAULT_LAYER);	
		jf.setLayeredPane(layeredPane);
		jf.setVisible(true);
		
		TypeDao td=new TypeDao();
		Vector ctype=td.query(rp.typeName);
		jtf1.setText(ctype.get(1).toString());
		jtf2.setText(ctype.get(2).toString());
		fg1=true;
		fg2=true;
//		jf.add(jl1);
//		jf.add(jtf1);
//		jf.add(jl2);
//		jf.add(jtf2);
//		jf.add(jb1);
		jb1.addActionListener(new ActionListener() {

			@Override
			public void actionPerformed(ActionEvent e) {
				// TODO Auto-generated method stub
			
				String name=jtf1.getText();
				int price=Integer.parseInt(jtf2.getText());
				Type type=new Type();
				type.setName(name);
				type.setPrice(price);
				try {
					int row=0;
					if(fg1&&fg2){
					
					row=td.update(type, ctype.get(0).toString());
					}else{
						JOptionPane.showMessageDialog(jb1, "������Ϣ��д����");
					}
					if(row>0){
						JOptionPane.showMessageDialog(jb1, "�����޸ĳɹ���");
						flag=true;
						jf.dispose();
					}else{
						JOptionPane.showMessageDialog(jb1, "�����޸�ʧ�ܣ�");
					}
				} catch (Exception e1) {
					// TODO Auto-generated catch block
					e1.printStackTrace();
				}
			}
			
			
		});
		jtf1.addFocusListener(new FocusListener() {
			
			@Override
			public void focusLost(FocusEvent e) {
				// TODO Auto-generated method stub
				String idc=String.valueOf(jtf1.getText());	
				
				Pattern p1=Pattern.compile("[\u4E00-\u9FA5]{2,8}");
				Matcher m1=p1.matcher(idc);
				fg1=m1.matches();
				if(!fg1){
					jlm.setIcon(nicon);
				}else{
					jlm.setIcon(oicon);
				}
			}
			
			@Override
			public void focusGained(FocusEvent e) {
				// TODO Auto-generated method stub
				
			}
		});
		jtf2.addFocusListener(new FocusListener() {
			
			@Override
			public void focusLost(FocusEvent e) {
				// TODO Auto-generated method stub
				String idc=String.valueOf(jtf2.getText());	
				
				Pattern p1=Pattern.compile("[0-9]{0,9}");
				Matcher m1=p1.matcher(idc);
				fg2=m1.matches();
				if(!fg2){
					jln.setIcon(nicon);
				}else{
					jln.setIcon(oicon);
				}
			}
			
			@Override
			public void focusGained(FocusEvent e) {
				// TODO Auto-generated method stub
				
			}
		});
		ImageIcon icon = new ImageIcon("image/timg.jpg");
		//��ʾ����ͼ��
		jf.setIconImage(icon.getImage());
	}
}
