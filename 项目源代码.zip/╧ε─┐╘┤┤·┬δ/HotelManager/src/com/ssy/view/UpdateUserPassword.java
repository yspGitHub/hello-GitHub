package com.ssy.view;

import java.awt.Color;
import java.awt.Font;
import java.awt.Toolkit;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.awt.event.FocusEvent;
import java.awt.event.FocusListener;
import java.awt.event.KeyEvent;
import java.awt.event.KeyListener;

import javax.swing.ImageIcon;
import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JLayeredPane;
import javax.swing.JOptionPane;
import javax.swing.JPanel;
import javax.swing.JPasswordField;
import javax.swing.JTextField;

import com.ssy.biz.IUserInfoBiz;
import com.ssy.biz.impl.UserInfoBizImpl;

public class UpdateUserPassword extends JFrame{
	private JLabel jl1,jl2,jl3,jl4,jl5;
	private JPasswordField jpf1,jpf2,jpf3; 
	private JButton jb1;
	String ypassword,npassword,rpassword;
	private JLayeredPane layeredPane=new JLayeredPane();
	private JPanel buttomJp;
	UserPanel up=new UserPanel(1);
	
	private boolean flag1=false,flag2=false;
	IUserInfoBiz iiz=new UserInfoBizImpl();
	
	public UpdateUserPassword(){
		init();
	}

	private void init() {
		// TODO Auto-generated method stub
		int width = (int)Toolkit.getDefaultToolkit().getScreenSize().getWidth();
		int height = (int)Toolkit.getDefaultToolkit().getScreenSize().getHeight();
	this.setBounds((width-360)/2, (height-360)/2, 360, 360);
	
	this.setLayout(null);
	this.setTitle("�޸�����");
	jl1=new JLabel("ԭ����:");
	jl1.setBounds(20,10,80,30);
	jl1.setFont(new Font("����", Font.BOLD, 16));//���������С
	jl4=new JLabel();
	jl4.setBounds(235,35,80,30);
	jl4.setFont(new Font("����", Font.BOLD,12));
	
	jpf1=new JPasswordField();
	jpf1.setBounds(110, 10, 180, 30);
	jpf1.setFont(new Font("����",Font.BOLD,16));
	jpf1.setBackground(new Color(149, 192, 247));
	jl2=new JLabel("������:");
	jl2.setBounds(20,80,80,30);
	jl2.setFont(new Font("����", Font.BOLD, 16));//���������С
	jpf2=new JPasswordField();
	jpf2.setBounds(110, 80, 180, 30);
	jpf2.setFont(new Font("����",Font.BOLD,16));
	jpf2.setBackground(new Color(149, 192, 247));
	jl3=new JLabel("��������:");
	jl3.setBounds(20,160,80,30);
	jl3.setFont(new Font("����", Font.BOLD, 16));
	jl5=new JLabel();
	jl5.setBounds(235,185,150,30);
	jl5.setFont(new Font("����", Font.BOLD, 12));
	//���������С
	jpf3=new JPasswordField();
	jpf3.setBounds(110, 160, 180, 30);
	jpf3.setFont(new Font("����",Font.BOLD,16));
	jpf3.setBackground(new Color(149, 192, 247));
	jb1=new JButton("�޸�");
	jb1.setBounds(140, 265, 80, 30);
	jpf2.addFocusListener(new FocusListener() {
		
		@Override
		public void focusLost(FocusEvent e) {
			// TODO Auto-generated method stub
			npassword=String.valueOf(jpf2.getPassword());
			rpassword=String.valueOf(jpf3.getPassword());
		
			if(npassword.equals(rpassword)){
				jl5.setText("�ظ���ȷ");
				jl5.setForeground(Color.blue);
				flag2=true;
			
				
			}else{
				if(!rpassword.equals("")||!rpassword.equals(null)){
			
				
				jl5.setText("�������벻һ��");
				jl5.setForeground(Color.red);
				}
				flag2=false;
			}
		}
		
		@Override
		public void focusGained(FocusEvent e) {
			// TODO Auto-generated method stub
			
		}
	});
	jb1.addActionListener(new ActionListener() {
		
		@Override
		public void actionPerformed(ActionEvent e) {
			// TODO Auto-generated method stub
			int row=0;
			if(flag1==true&&flag2==true){
				npassword=String.valueOf(jpf2.getPassword());
				System.out.println(up.id+"  "+npassword);
				row=iiz.update(up.id, npassword);
			}
			if(row>0){
				JOptionPane.showMessageDialog(jb1, "�����޸ĳɹ���");
				dispose();
			}
		}
	});
	jpf3.addFocusListener(new FocusListener() {
		
		@Override
		public void focusLost(FocusEvent e) {
			// TODO Auto-generated method stub
			npassword=String.valueOf(jpf2.getPassword());
			rpassword=String.valueOf(jpf3.getPassword());
		
			if(npassword.equals(rpassword)){
				jl5.setText("�ظ���ȷ");
				jl5.setForeground(Color.blue);
				flag2=true;
			
				
			}else{
				flag2=false;
				jl5.setText("�������벻һ��");
				jl5.setForeground(Color.red);
			}
		}
		
		@Override
		public void focusGained(FocusEvent e) {
			// TODO Auto-generated method stub
			
		}
	});

	jpf1.addFocusListener(new FocusListener() {
		
		@Override
		public void focusLost(FocusEvent e) {
			// TODO Auto-generated method stub
			ypassword=String.valueOf(jpf1.getPassword());
			
			String id=up.id;
		
			try {
				String sypassword=iiz.findPass(id);
				if(ypassword.equals(sypassword)){
					jl4.setText("������ȷ");
					jl4.setForeground(Color.blue);
					flag1=true;
				}else{
					flag1=false;
					jl4.setText("�������");
					jl4.setForeground(Color.red);
				}
			} catch (Exception e1) {
				// TODO Auto-generated catch block
				e1.printStackTrace();
			}
			System.out.println();
		}
		
		@Override
		public void focusGained(FocusEvent e) {
			// TODO Auto-generated method stub
			
		}
	});
	layeredPane.add(jl2, JLayeredPane.MODAL_LAYER);
	layeredPane.add(jpf1, JLayeredPane.MODAL_LAYER);
	layeredPane.add(jpf2, JLayeredPane.MODAL_LAYER);
	layeredPane.add(jl3, JLayeredPane.MODAL_LAYER);
	layeredPane.add(jl1, JLayeredPane.MODAL_LAYER);
	layeredPane.add(jpf3, JLayeredPane.MODAL_LAYER);
	layeredPane.add(jl4, JLayeredPane.MODAL_LAYER);
	layeredPane.add(jb1, JLayeredPane.MODAL_LAYER);
	layeredPane.add(jl5, JLayeredPane.MODAL_LAYER);
	ImageIcon bc = new ImageIcon("image/b.jpg");
	buttomJp = new MyPanel(bc.getImage());
	buttomJp.setBounds(0, 0, 360, 360);
	layeredPane.add(buttomJp, JLayeredPane.DEFAULT_LAYER);	
	this.setLayeredPane(layeredPane);
	this.setVisible(true);
//	this.add(jl1);
//	this.add(jl2);
//	this.add(jl3);
//	this.add(jpf1);
//	this.add(jpf2);
//	this.add(jpf3);
//	this.add(jl4);
//	this.add(jb1);
//	this.add(jl5);
//	this.setVisible(true);
	ImageIcon icon = new ImageIcon("image/timg.jpg");
	//��ʾ����ͼ��
	this.setIconImage(icon.getImage());
	}
	
}
