package com.ssy.view;

import java.awt.Color;
import java.awt.Font;
import java.awt.Image;
import java.awt.Toolkit;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.awt.event.FocusEvent;
import java.awt.event.FocusListener;
import java.awt.event.ItemEvent;
import java.awt.event.ItemListener;
import java.awt.event.KeyEvent;
import java.awt.event.KeyListener;
import java.util.Calendar;
import java.util.TimeZone;
import java.util.Vector;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

import javax.swing.Icon;
import javax.swing.ImageIcon;
import javax.swing.JButton;
import javax.swing.JComboBox;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JLayeredPane;
import javax.swing.JOptionPane;
import javax.swing.JPanel;
import javax.swing.JTextField;

import com.ssy.biz.IRoomBiz;
import com.ssy.biz.impl.RoomBizImpl;
import com.ssy.dao.CustomerDao;
import com.ssy.dao.LogDao;
import com.ssy.dao.MemberDao;
import com.ssy.dao.TypeDao;
import com.ssy.entity.Customer;
import com.ssy.entity.Log;
import com.ssy.entity.Room;
import com.ssy.entity.Vip;

public class InsertCustomer {
	private JFrame jf;
	private JButton jb1;
	private JLabel jl1,jl2,jl3,jl4,jl5,jl6,jl7,jl8,jl9,jla,jlb,jlc,jld,jle,jlf,jlm,jln,jlh;
	
	private JTextField jtf1,jtf2,jtf3,jtf4;
	private JComboBox jcb2,jcb1,jcb3;
	public static int flag;
	ImageIcon nicon=new ImageIcon("image/no.png");
	ImageIcon oicon=new ImageIcon("image/ok.png");
	private String idCard,name,vip,roomId,roomType;
	private JLayeredPane layeredPane=new JLayeredPane();
	private JPanel buttomJp;
	private String relPrice,price,tel="";
	private String num="1";
	private int n=1;
	private boolean fg1,fg2,fg3;
	private int vipId=4;
	String lhour="12:00";
	String leaveTime;
	String vipName;
	String count="100";
	 Log log=new Log();
	int lday,lmonth,lyear;
	int vipFlag=0;
	MemberDao md=new MemberDao();
	public InsertCustomer(){
		
		init();
	}
	

	private int init() {
	
		jf=new JFrame("�ͻ���Ϣ");
		ImageIcon icon = new ImageIcon("image/timg.jpg");
		//��ʾ����ͼ��
		jf.setIconImage(icon.getImage());
		int width = (int)Toolkit.getDefaultToolkit().getScreenSize().getWidth();
		int height = (int)Toolkit.getDefaultToolkit().getScreenSize().getHeight();
		jf.setBounds((width-300)/2, (height-600)/2, 320, 600);
		jf.setLayout(null);
		ImageIcon bc = new ImageIcon("image/b.jpg");
		buttomJp = new MyPanel(bc.getImage());
		buttomJp.setBounds(0, 0, 320, 600);
		jf.setVisible(true);
		jl1=new JLabel("����֤:");
		jl1.setBounds(20,10,60,30);
		jl1.setFont(new Font("����", Font.BOLD, 16));//���������С
		jtf1=new JTextField();
		jtf1.setBounds(90, 10, 180, 30);
		jtf1.setFont(new Font("����",Font.BOLD,16));
		jtf1.setBackground(new Color(149, 192, 247));
		jlm=new JLabel();
		jlm.setBounds(280, 18, 16, 16);
		jl2=new JLabel("����:");	
		jl2.setBounds(20,60,60,30);
		jl2.setFont(new Font("����", Font.BOLD, 16));
		jtf2=new JTextField();
		jtf2.setBounds(90, 60, 180, 30);
		jln=new JLabel();
		jln.setBounds(280, 68, 16, 16);
		jtf2.setBackground(new Color(149, 192, 247));
		jtf2.setFont(new Font("����", Font.BOLD, 16));
		jl3=new JLabel("�绰:");
		jl3.setBounds(20,110,60,30);
		jl3.setFont(new Font("����", Font.BOLD, 16));
		jtf3=new JTextField();
		jtf3.setBounds(90, 110, 180, 30);
		jlh=new JLabel();
		jlh.setBounds(280, 118, 16, 16);
		jtf3.setBackground(new Color(149, 192, 247));
		jtf3.setFont(new Font("����", Font.BOLD, 16));
		jl4=new JLabel("��Ա:");
		jl4.setBounds(20,160,60,30);
		jl4.setFont(new Font("����", Font.BOLD, 16));
		jl5=new JLabel();
		jl5.setBounds(90,160,90,30);
		jl5.setFont(new Font("����", Font.BOLD, 16));
		jl6=new JLabel("����:");
		jl6.setBounds(20,210,60,30);
		jl6.setFont(new Font("����", Font.BOLD, 16));
		jl7=new JLabel();
		jl7.setBounds(90,210,60,30);
		jl7.setFont(new Font("����", Font.BOLD, 16));
		jl8=new JLabel("����:");
		jl8.setBounds(20,260,90,30);
		jl8.setFont(new Font("����", Font.BOLD, 16));
		jl9=new JLabel();
		jl9.setBounds(90,260,90,30);
		jl9.setFont(new Font("����", Font.BOLD, 16));
		jle=new JLabel("����:");	
		jle.setBounds(20,310,90,30);
		jle.setFont(new Font("����", Font.BOLD, 16));
		jcb1=new JComboBox();
		jcb1.setBounds(90,310,90,30);
		for(int i=1;i<31;i++){
			jcb1.addItem(i);
		}
		jla=new JLabel("�۸�:");
		jla.setBounds(20,360,60,30);
		jla.setFont(new Font("����", Font.BOLD, 16));
		jlb=new JLabel();
		jlb.setBounds(90,360,60,30);
		jlb.setFont(new Font("����", Font.BOLD, 16));
		jlc=new JLabel("�ۺ��:");
		jlc.setBounds(20,410,60,30);
		jlc.setFont(new Font("����", Font.BOLD, 16));
		jld=new JLabel();
		jld.setBounds(90,410,90,30);
		jld.setFont(new Font("����", Font.BOLD, 16));	
		jb1=new JButton("ȷ�Ͽ���");
		jb1.setBounds(90,500,120,40);
		jb1.setBackground(Color.white);
		jb1.setForeground(Color.black);
		jb1.setFont(new Font("����", Font.BOLD, 20));
		jb1.setOpaque(false);
		
		layeredPane.add(jle, JLayeredPane.MODAL_LAYER);
		layeredPane.add(jtf1, JLayeredPane.MODAL_LAYER);
		layeredPane.add(jcb1, JLayeredPane.MODAL_LAYER);
		layeredPane.add(jl1, JLayeredPane.MODAL_LAYER);
		//layeredPane.add(jb1, JLayeredPane.MODAL_LAYER);
		layeredPane.add(jl2, JLayeredPane.MODAL_LAYER);	
		layeredPane.add(jtf2, JLayeredPane.MODAL_LAYER);
		layeredPane.add(jl3, JLayeredPane.MODAL_LAYER);
		layeredPane.add(jtf3, JLayeredPane.MODAL_LAYER);
		layeredPane.add(jl4, JLayeredPane.MODAL_LAYER);
		layeredPane.add(jl5, JLayeredPane.MODAL_LAYER);
		layeredPane.add(jl6, JLayeredPane.MODAL_LAYER);
		layeredPane.add(jl7, JLayeredPane.MODAL_LAYER);
		layeredPane.add(jlm, JLayeredPane.MODAL_LAYER);
		layeredPane.add(jln, JLayeredPane.MODAL_LAYER);
		layeredPane.add(jlh, JLayeredPane.MODAL_LAYER);
		layeredPane.add(jl8, JLayeredPane.MODAL_LAYER);
		layeredPane.add(jl9, JLayeredPane.MODAL_LAYER);
		layeredPane.add(jla, JLayeredPane.MODAL_LAYER);
		layeredPane.add(jlb, JLayeredPane.MODAL_LAYER);
		layeredPane.add(jlc, JLayeredPane.MODAL_LAYER);
		layeredPane.add(jld, JLayeredPane.MODAL_LAYER);
		layeredPane.add(jb1, JLayeredPane.MODAL_LAYER);
		layeredPane.add(buttomJp, JLayeredPane.DEFAULT_LAYER);	
		jf.setLayeredPane(layeredPane);
		IRoomBiz irz=new  RoomBizImpl();
		RoomPanel rp=new RoomPanel();
		Vector<Vector> rooms=new Vector<Vector>();
		
		try {
			rooms=irz.vagueFind(rp.id);
			for(Vector room :rooms){
				roomType=room.get(2).toString();
				roomId=room.get(0).toString();
				jl7.setText(roomId);
				jl9.setText(roomType);
				TypeDao td=new TypeDao();
				Vector type=td.query(roomType);
				price=type.get(2).toString();
				int sprice=Integer.parseInt(price);
				int d=Integer.parseInt(num);
				int count=sprice*d;
				price=String.valueOf(count);
				jlb.setText(price);
				
			}
		} catch (Exception e1) {
			// TODO Auto-generated catch block
			e1.printStackTrace();
		}
		jb1.addActionListener(new ActionListener() {
			
			@Override
			public void actionPerformed(ActionEvent e) {
				tel=jtf3.getText();
				name=jtf2.getText();
				n=Integer.parseInt(num);
				
				Calendar cld=Calendar.getInstance(TimeZone.getTimeZone("GMT+08:00"));
			
				int year=cld.get(Calendar.YEAR);
				
				 int month = cld.get(Calendar.MONTH) + 1;   //��ȡ�·ݣ�0��ʾ1�·�
				  int day = cld.get(Calendar.DAY_OF_MONTH);    //��ȡ��ǰ����
				   
				  //int first = cld.getActualMinimum(c.DAY_OF_MONTH);    //��ȡ������С����
				  //int last = cld.getActualMaximum(c.DAY_OF_MONTH);    //��ȡ�����������
				  int hour = cld.get(Calendar.HOUR_OF_DAY);       //��ȡ��ǰСʱ
				  int mintue = cld.get(Calendar.MINUTE);          //��ȡ��ǰ����
				  int second = cld.get(Calendar.SECOND);    
				  String nowtime=year + "-" + month + "-"+ day;
				  String open=nowtime;
		
				
				
				// TODO Auto-generated method stub	 		
				 vip=jl5.getText();
				 System.out.println(vip+"tt");
				 Vip vipr=new Vip();
				 vipr.setName(vip);
				 vipr.setId(vipId);
				 relPrice=jld.getText();
				 Room room=new Room();
				 room.setId(roomId);
				 Customer customer=new Customer();
				 customer.setIdCard(idCard);
				 customer.setName(name);
				 customer.setRoom(room);
				 customer.setTel(tel);
				 customer.setVip(vipr);
				 customer.setOpen(open);
				 System.out.println(leaveTime+"   time");
				 customer.setLeave(leaveTime);
				 CustomerDao cd=new CustomerDao();
				 log.setTime(open);
				 log.setCusId(idCard);
				 log.setMoney(relPrice);
				 log.setOption("����");
				 log.setRoomId(roomId);
				 Login lg=new Login(1);
				System.out.println(lg.UserId+"  lll");
				 log.setUserId(lg.UserId);
				 System.out.println(relPrice+" "+"idCard"+" "+" "+open+" "+roomId);
				 int ff=cd.find(idCard).size();
				 int row=0;
				 if(ff>0){
					 JOptionPane.showMessageDialog(jb1, idCard+"���ڱ���Ǽǿ����������ظ��Ǽ�");
				 }else{
				
					 if(fg1&&fg2&&fg3){
					row=cd.insert(customer);
					
					 }else{
						 JOptionPane.showMessageDialog(jb1,"������Ϣ��д����");
					 }
				
				
				
			
				 if(row>0){
						try {
							LogDao ld=new LogDao();
						
							ld.insert(log);
						int line=0;	
						line=irz.openRoom(roomId,����״̬.������.toString());
						System.out.println(vipId+"zsz");
							if(vipId!=0&&vipId!=4){
								
								Vector mevector=md.find(idCard);
							System.out.println(mevector.size());
								int flagJf=Integer.parseInt(mevector.get(4).toString());
								int countInt=Integer.parseInt(num)*10+flagJf;
								int jf=md.update(idCard,countInt);
								System.out.println(countInt);
								
								
								if(jf>0){
									System.out.println("�������֣�"+countInt);
								}
							
								if(flagJf>=100&&flagJf<500){
									md.update(2, idCard);
									//JOptionPane.showMessageDialog(jb1, name+"�Ѿ��������ƽ��Ա��");
								}
								if(flagJf>=500){
									md.update(3, idCard);
									//JOptionPane.showMessageDialog(jb1, name+"�Ѿ��������׽��Ա��");
								}
								System.out.println();
								
							}
							
							if(line>0){
								JOptionPane.showMessageDialog(jb1, roomId+"�ŷ����ѿ�");
							//	RoomPanel rp=new RoomPanel(1);
								//rp.init();
								jf.dispose();
							}
						} catch (Exception e1) {
							// TODO Auto-generated catch block
							e1.printStackTrace();
						}
						
				 }
					
				System.out.println(idCard+"\t"+name+"\t"+tel+"\t"+vip+"\t"+roomId+"\t"+roomType+"\t"+price+"\t"+relPrice);
			
			}
			}
		});
		jtf1.addKeyListener(new KeyListener() {
			
			@Override
			public void keyTyped(KeyEvent e) {
				// TODO Auto-generated method stub
				
			}
			
			@Override
			public void keyReleased(KeyEvent e) {
				// TODO Auto-generated method stub
				
				System.out.println(1);
				 Vector vip=new Vector();
				 idCard=jtf1.getText();
				try { 
			
					System.out.println(2);
					vip=md.find(idCard);
				System.out.println(vip.size());
					 if(vip.size()>0){
			
						 vipName=vip.get(0).toString();
						 vipId=Integer.parseInt(vip.get(5).toString());
						 System.out.println(vipId+"zz");
						 jl5.setText(vipName);
						 count=vip.get(1).toString();
						 name=vip.get(2).toString();
						 tel=vip.get(3).toString();
					
						double relCount=(double)(Integer.parseInt(count)/100.0);
						double rel=(relCount*((double)Integer.parseInt(price)));
						relPrice=String.valueOf((int)(rel));
						jld.setText(relPrice);
						
						jtf2.setText(name);
						
						jtf3.setText(tel);
						jln.setIcon(oicon);
						jlh.setIcon(oicon);
						fg2=true;
						fg3=true;
						
						
					
					 }else{
						 System.out.println(leaveTime+"ddd");
						 jl5.setText("�ǻ�Ա");
						 jld.setText(price);
						 jtf2.setText("");
						 jtf3.setText("");
						 vipId=4;
					 }
				} catch (Exception e1) {
					// TODO Auto-generated catch block
					e1.printStackTrace();
				}
			
				
			}
			
			@Override
			public void keyPressed(KeyEvent e) {
				// TODO Auto-generated method stub
				
			}
		});
		jcb1.addItemListener(new ItemListener() {
			
			@Override
			public void itemStateChanged(ItemEvent e) {
				// TODO Auto-generated method stub
				if(e.getStateChange()==ItemEvent.SELECTED){
					num=jcb1.getSelectedItem().toString();
					int n=Integer.parseInt(num);
			
				Calendar cld1=Calendar.getInstance(TimeZone.getTimeZone("GMT+08:00"));
				System.out.println("   ++"+n);
				cld1.add(Calendar.DATE,n);
				
				lyear=cld1.get(Calendar.YEAR);
				  lmonth = cld1.get(Calendar.MONTH) + 1;   //��ȡ�·ݣ�0��ʾ1�·�
				   lday = cld1.get(Calendar.DAY_OF_MONTH);  
				   leaveTime=lyear + "-" + lmonth + "-"+ lday;
		
				}
			
				try {
					Vector<Vector> rooms=new Vector<Vector>();
					rooms=irz.vagueFind(rp.id);
					for(Vector room :rooms){
						roomType=room.get(2).toString();
						roomId=room.get(0).toString();
						jl7.setText(roomId);
						jl9.setText(roomType);
						TypeDao td=new TypeDao();
						Vector type=td.query(roomType);
						price=type.get(2).toString();
						int sprice=Integer.parseInt(price);
						int d=Integer.parseInt(num);
						int sd=sprice*d;
						price=String.valueOf(sd);
					
					
						jld.setText(relPrice);
						if(vipId!=0&&vipId!=4){
							 double relCount=(double)(Integer.parseInt(count)/100.0);
							 double rel=(relCount*((double)Integer.parseInt(price)));
							relPrice=String.valueOf((int)(rel));
//							System.out.println(price+"price");
//							System.out.println(relPrice+"real");
							jld.setText(relPrice);
							
						}else{
							jld.setText(price);
						}
						
						
					}
				} catch (Exception e1) {
					// TODO Auto-generated catch block
					e1.printStackTrace();
				}
			}
		});
		jtf1.addFocusListener(new FocusListener() {
		
		@Override
		public void focusLost(FocusEvent e) {
			// TODO Auto-generated method stub
			String idc=String.valueOf(jtf1.getText());	
			
			Pattern p1=Pattern.compile("[0-9]{17}[0-9a-zA-Z]{1}");
			Matcher m1=p1.matcher(idc);
			fg1=m1.matches();
			if(!fg1){
				jlm.setIcon(nicon);
			}else{
				jlm.setIcon(oicon);
			}
		}
		
		@Override
		public void focusGained(FocusEvent e) {
			// TODO Auto-generated method stub
		
		}
	});
		jtf2.addFocusListener(new FocusListener() {
			
			@Override
			public void focusLost(FocusEvent e) {
				// TODO Auto-generated method stub
				String idc=String.valueOf(jtf2.getText());	
				
				Pattern p1=Pattern.compile("[\u4E00-\u9FA5]{2,5}");
				Matcher m1=p1.matcher(idc);
				fg2=m1.matches();
				if(!fg2){
					jln.setIcon(nicon);
				}else{
					jln.setIcon(oicon);
				}
			}
			
			@Override
			public void focusGained(FocusEvent e) {
				// TODO Auto-generated method stub
				
			}
		});
		jtf3.addFocusListener(new FocusListener() {
			
			@Override
			public void focusLost(FocusEvent e) {
				// TODO Auto-generated method stub
				String idc=String.valueOf(jtf3.getText());	
				
				Pattern p1=Pattern.compile("[0-9]{11}");
				Matcher m1=p1.matcher(idc);
				fg3=m1.matches();
				if(!fg3){
					jlh.setIcon(nicon);
				}else{
					jlh.setIcon(oicon);
				}
			}
			
			@Override
			public void focusGained(FocusEvent e) {
				// TODO Auto-generated method stub
				
			}
		});
		return flag;
		
		
	}

}
