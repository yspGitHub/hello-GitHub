package com.ssy.view;

import java.awt.Color;
import java.awt.Component;
import java.awt.Dimension;
import java.awt.Font;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.awt.event.KeyEvent;
import java.awt.event.KeyListener;
import java.util.Vector;

import javax.swing.JButton;
import javax.swing.JComboBox;
import javax.swing.JLabel;
import javax.swing.JPanel;
import javax.swing.JScrollPane;
import javax.swing.JTable;
import javax.swing.JTextField;
import javax.swing.SwingConstants;
import javax.swing.table.DefaultTableCellRenderer;
import javax.swing.table.DefaultTableModel;
import javax.swing.table.JTableHeader;
import javax.swing.table.TableCellRenderer;
import javax.swing.table.TableColumn;

import com.ssy.dao.LogDao;

public class LogPanel extends JPanel {
	private JButton jb1, jb2, jb3, jb4, jb5, jb6, jb7, jb8, jb9,jba;
	private JComboBox jcb1, jcb2, jcb3, jcb4, jcb5;
	private JLabel jl1, jl2, jl3;
	private JTextField jtx1;
	DefaultTableModel tableModel = new DefaultTableModel();
	JScrollPane jsp;
	Vector title;
	private JTable jt;
	Vector<Vector> vector;
	LogDao ld = new LogDao();

	public LogPanel() {
		init();
	}

	public void initFind() {
		this.setBackground(Color.white);
		vector = new Vector<Vector>();
		title = new Vector();
		title.add("ʱ��");
		title.add("����֤");
		title.add("����");
		title.add("����");
		title.add("���");
		title.add("������Ա");

		try {
			System.out.println(vector.size());
			vector = ld.find();
		} catch (Exception e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		tableModel.setDataVector(vector, title);
		jt.getColumnModel().getColumn(0).setPreferredWidth(200);
		jt.getColumnModel().getColumn(1).setPreferredWidth(200);
	}

	private void init() {
		// TODO Auto-generated method stub
		this.setOpaque(false);
		jt = new JTable() {
			public boolean isCellEditable(int row, int column) {
				return false;
			}
		};
		jt.setModel(tableModel);
		jt.validate();
		jl1 = new JLabel("��ѯ:");
		jl1.setBounds(12, 20, 90, 20);
		jl1.setFont(new Font("����", Font.BOLD, 20));
		jl2 = new JLabel("�����ۻ�Ӫҵ��:");
		jl2.setBounds(240, 20, 200, 20);

		jl2.setFont(new Font("����", Font.BOLD, 20));
		jl3 = new JLabel();
		int count = ld.countMoney();
		jl3.setText(String.valueOf(count));
		jl3.setBounds(410, 15, 300, 30);
		jl3.setFont(new Font("����", Font.BOLD, 40));
		jl3.setForeground(Color.red);
		jtx1 = new JTextField();
		jtx1.setBounds(65, 16, 150, 30);
		jtx1.setOpaque(false);
		jsp = new JScrollPane(jt);
		jsp.setBounds(10, 80, 930, 400);
		jt.setFont(new Font("����", Font.BOLD, 20));
		jt.setRowHeight(25);

		jt.getTableHeader().setReorderingAllowed(false);
		this.setBounds(-10, 0, 900, 400);
		jb1 = new JButton("ˢ��");
		jb1.setBounds(1000, 30, 120, 40);
		jb1.setBackground(Color.white);
		jb1.setOpaque(false);
		jb1.setForeground(Color.black);
		jb1.setFont(new Font("����", Font.BOLD, 20));
		jb1.setFocusPainted(false);
		jb2 = new JButton("�����¼");
		jb2.setBounds(1000, 170, 120, 40);
		jb2.setEnabled(false);
		jb2.setBackground(Color.white);
		jb2.setOpaque(false);
		jb2.setFocusPainted(false);
	
		this.setLayout(null);
		this.add(jsp);
		this.add(jl1);
		this.add(jl2);
		this.add(jl3);
		this.add(jtx1);
		this.add(jb1);
		initFind();

		DefaultTableCellRenderer render = new DefaultTableCellRenderer() {
			public Component getTableCellRendererComponent(JTable table, Object value, boolean isSelected,
					boolean hasFocus, int row, int column) {

				setOpaque(false);
				jt.setSelectionForeground(Color.black);
				if (isSelected) {
					if (row == jt.getSelectedRow()) {
						setOpaque(true);
						jt.setSelectionForeground(Color.white);

					}
				}

				return super.getTableCellRendererComponent(jt, value, true, false, row, column);
			}
		};
		jt.setSelectionBackground(new Color(149, 192, 247));

		render.setOpaque(false);

		jt.setDefaultRenderer(Object.class, render);

		jt.getTableHeader().setReorderingAllowed(false);
		jt.setModel(tableModel);
		jt.validate();
		jt.setOpaque(false);
		jsp.setOpaque(false);
		jsp.getViewport().setOpaque(false);// ��JScrollPane����Ϊ͸��
		jsp.setOpaque(false);// ���м��viewport����Ϊ͸��
		jsp.setViewportView(jt);// װ�ر���
		jsp.setColumnHeaderView(jt.getTableHeader());// ����ͷ����HeaderView���֣�
		jsp.getColumnHeader().setOpaque(false);// ��ȡ��ͷ����������Ϊ͸��

		jt.getTableHeader().setReorderingAllowed(false);
		jt.setDefaultRenderer(Object.class, render);

		JTableHeader header = jt.getTableHeader();// ��ȡͷ��
		header.setPreferredSize(new Dimension(30, 26));
		header.setOpaque(false);// ����ͷ��Ϊ͸��
		header.getTable().setOpaque(false);// ����ͷ������ı���͸��
		header.setDefaultRenderer(new HeaderCellRenderer());
		TableCellRenderer headerRenderer = header.getDefaultRenderer();
		if (headerRenderer instanceof JLabel) {
			((JLabel) headerRenderer).setHorizontalAlignment(JLabel.CENTER);
			((JLabel) headerRenderer).setOpaque(false);
		}
		;
		jt.getColumnModel().getColumn(0).setPreferredWidth(200);
		jt.getColumnModel().getColumn(1).setPreferredWidth(200);
		jt.getTableHeader().setFont(new Font("����", Font.BOLD, 20));
		jtx1.addKeyListener(new KeyListener() {

			@Override
			public void keyTyped(KeyEvent e) {
				// TODO Auto-generated method stub

			}

			@Override
			public void keyReleased(KeyEvent e) {
				// TODO Auto-generated method stub
				String info = jtx1.getText();
				vector = new Vector<Vector>();
				title = new Vector();
				title.add("ʱ��");
				title.add("����֤");
				title.add("����");
				title.add("����");
				title.add("���");
				title.add("������Ա");

				try {
					// System.out.println(vector.size());
					vector = ld.mfind(info);
				} catch (Exception e1) {
					// TODO Auto-generated catch block
					e1.printStackTrace();
				}
				tableModel.setDataVector(vector, title);
				jt.getColumnModel().getColumn(0).setPreferredWidth(200);
				jt.getColumnModel().getColumn(1).setPreferredWidth(200);

			}

			@Override
			public void keyPressed(KeyEvent e) {
				// TODO Auto-generated method stub

			}
		});
		jb1.addActionListener(new ActionListener() {

			@Override
			public void actionPerformed(ActionEvent e) {
				// TODO Auto-generated method stub
				initFind();
				int count = ld.countMoney();
				jl3.setText(String.valueOf(count));
				jtx1.setText("");
			}
		});
		this.setVisible(true);
	}
}
