package com.ssy.view;

import java.awt.Toolkit;
import java.util.List;

import javax.swing.ImageIcon;
import javax.swing.JFrame;
import javax.swing.JLabel;

import com.fqw.util.BackgroundUpload;

public class BackgroundPic extends JFrame{
	public BackgroundPic(){init();}

	private void init() {
		// TODO Auto-generated method stub
		int width = (int) Toolkit.getDefaultToolkit().getScreenSize().getWidth();
		int height = (int) Toolkit.getDefaultToolkit().getScreenSize().getHeight();
		this.setBounds((width - 1200) / 2, (height - 900) / 2, 1200, 800);
		this.setLayout(null);
		this.setVisible(true);
		BackgroundUpload bu=new BackgroundUpload();
		int[] arr1=new int[10];
		List<String> pics=bu.traverseFolder2("image");
		int i=0;
		for(String pic :pics){
			i++;
			
			ImageIcon img=new ImageIcon(pic);
			//JLabel arr1[i]=new JLabel();
			//jl.setIcon(img);

			
		}
	} 
}
