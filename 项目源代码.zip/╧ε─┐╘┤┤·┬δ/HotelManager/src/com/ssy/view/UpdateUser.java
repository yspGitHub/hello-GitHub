package com.ssy.view;

import java.awt.Color;
import java.awt.Font;
import java.awt.Toolkit;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.awt.event.FocusEvent;
import java.awt.event.FocusListener;
import java.awt.event.ItemEvent;
import java.awt.event.ItemListener;
import java.awt.event.KeyEvent;
import java.awt.event.KeyListener;
import java.util.Vector;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

import javax.swing.ImageIcon;
import javax.swing.JButton;
import javax.swing.JCheckBox;
import javax.swing.JComboBox;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JLayeredPane;
import javax.swing.JOptionPane;
import javax.swing.JPanel;
import javax.swing.JPasswordField;
import javax.swing.JTextField;
import javax.swing.event.ChangeEvent;
import javax.swing.event.ChangeListener;

import com.ssy.biz.IUserInfoBiz;
import com.ssy.biz.impl.UserInfoBizImpl;
import com.ssy.entity.UserInfo;

public class UpdateUser {
	private JFrame jf;
	private JLabel jl1, jl2, jl3, jl4, jl5, jl6;
	private JLabel jla, jlb, jlc, jld, jle;
	private JTextField jtf1, jtf2, jtf4, jtf5, jtf6;
	private JPasswordField jpf;
	private JButton jb1;
	private JCheckBox jck1;
	private JComboBox jcb1;
	private int auth = 0;
	private JLayeredPane layeredPane = new JLayeredPane();
	private JPanel buttomJp;
	private boolean i = true, j = true, k = true, l = true;
	private boolean flag;
	private boolean flag2=true, flag3=true, flag4=true, flag5=true, flag6=true;
	private String id, name, password, tel, adress;
	private UserPanel up = new UserPanel(1);

	public UpdateUser() {
		init();
	}

	private void init() {
		// TODO Auto-generated method stub
		jf = new JFrame("�޸�Ա��");
		int width = (int) Toolkit.getDefaultToolkit().getScreenSize().getWidth();
		int height = (int) Toolkit.getDefaultToolkit().getScreenSize().getHeight();
		jf.setBounds((width - 360) / 2, (height - 360) / 2, 300, 500);
		jf.setLayout(null);
		jf.setVisible(true);
		IUserInfoBiz uib = new UserInfoBizImpl();
		System.out.println(up.id+"mmmz");
		Vector vuser = uib.seek(up.id);
		System.out.println(vuser.get(2).toString());
		jl1 = new JLabel("����:");
		jl1.setBounds(20, 10, 60, 30);
		jl1.setFont(new Font("����", Font.BOLD, 16));// ���������С
		jla = new JLabel();
		jla.setBounds(200, 40, 100, 30);
		jla.setForeground(Color.red);
		jla.setFont(new Font("����", Font.BOLD, 12));
		jtf1 = new JTextField();
		jtf1.setBounds(90, 10, 180, 30);

		jtf1.setBackground(Color.gray);
		jtf1.setText(up.id);
		jtf1.setEnabled(false);
		jtf1.setFocusable(false);
		jl2 = new JLabel("����:");
		jl2.setBounds(20, 70, 60, 30);
		jl2.setFont(new Font("����", Font.BOLD, 16));// ���������С
		jlb = new JLabel();
		jlb.setBounds(200, 100, 100, 30);
		jlb.setForeground(Color.red);
		jlb.setFont(new Font("����", Font.BOLD, 12));
		jtf2 = new JTextField();
		jtf2.setBounds(90, 70, 180, 30);
		jtf2.setText(vuser.get(1).toString());
		jtf2.setBackground(new Color(149, 192, 247));

		jl4 = new JLabel("�绰:");
		jl4.setBounds(20, 130, 60, 30);
		jl4.setFont(new Font("����", Font.BOLD, 16));// ���������С
		jld = new JLabel();
		jld.setBounds(200, 160, 100, 30);
		jld.setForeground(Color.red);
		jld.setFont(new Font("����", Font.BOLD, 12));
		jtf4 = new JTextField();
		jtf4.setBounds(90, 130, 180, 30);
		jtf4.setText("������11λ������");
		jtf4.setBackground(new Color(149, 192, 247));

		jtf4.setText(vuser.get(3).toString());
		jl5 = new JLabel("סַ:");
		jl5.setBounds(20, 190, 60, 30);
		jl5.setFont(new Font("����", Font.BOLD, 16));// ���������С
		jle = new JLabel();
		jle.setBounds(200, 220, 100, 30);
		jle.setForeground(Color.red);
		jle.setFont(new Font("����", Font.BOLD, 12));
		jtf5 = new JTextField();
		jtf5.setBounds(90, 190, 180, 30);
		jtf5.setBackground(new Color(149, 192, 247));
		jtf5.setText(vuser.get(2).toString());
		jl6 = new JLabel("����Ա:");
		jl6.setBounds(20, 250, 180, 30);
		jl6.setFont(new Font("����", Font.BOLD, 16));
		jck1 = new JCheckBox();
		jck1.setBounds(90, 250, 30, 30);
		jck1.setOpaque(false);
		
		jb1 = new JButton("�޸�");
		jb1.setBounds(110, 370, 90, 30);
		jtf1.setFont(new Font("����", Font.BOLD, 20));
		jtf1.setForeground(Color.BLACK);
		jtf2.setFont(new Font("����", Font.BOLD, 20));
		flag = jck1.isSelected();
		System.out.println("falg:" + flag);
		if (flag == true) {
			auth = 1;
		} else {
			auth = 0;
		}
		jtf4.setFont(new Font("����", Font.BOLD, 20));
		jtf5.setFont(new Font("����", Font.BOLD, 20));
		int au = Integer.parseInt(vuser.get(4).toString());
		if (au == 0) {
			jck1.setSelected(false);
		} else {
			jck1.setSelected(true);
		}
		layeredPane.add(jla, JLayeredPane.MODAL_LAYER);
		layeredPane.add(jlb, JLayeredPane.MODAL_LAYER);

		layeredPane.add(jld, JLayeredPane.MODAL_LAYER);
		layeredPane.add(jle, JLayeredPane.MODAL_LAYER);
		layeredPane.add(jl1, JLayeredPane.MODAL_LAYER);
		layeredPane.add(jtf1, JLayeredPane.MODAL_LAYER);
		layeredPane.add(jl2, JLayeredPane.MODAL_LAYER);
		layeredPane.add(jtf2, JLayeredPane.MODAL_LAYER);
		// layeredPane.add(jl3, JLayeredPane.MODAL_LAYER);
		// layeredPane.add(jpf, JLayeredPane.MODAL_LAYER);

		layeredPane.add(jl4, JLayeredPane.MODAL_LAYER);
		layeredPane.add(jtf4, JLayeredPane.MODAL_LAYER);
		layeredPane.add(jl5, JLayeredPane.MODAL_LAYER);
		layeredPane.add(jtf5, JLayeredPane.MODAL_LAYER);
		layeredPane.add(jb1, JLayeredPane.MODAL_LAYER);
		layeredPane.add(jck1, JLayeredPane.MODAL_LAYER);
		layeredPane.add(jl6, JLayeredPane.MODAL_LAYER);
		ImageIcon bc = new ImageIcon("image/b.jpg");
		buttomJp = new MyPanel(bc.getImage());
		buttomJp.setBounds(0, 0, 300, 500);
		layeredPane.add(buttomJp, JLayeredPane.DEFAULT_LAYER);
		jf.setLayeredPane(layeredPane);
		jf.setVisible(true);

		jtf5.addFocusListener(new FocusListener() {

			@Override
			public void focusLost(FocusEvent e) {
				// TODO Auto-generated method stub
				id = jtf5.getText();
				if (id == "" || id == null) {
					jtf5.setText("�����������ַ������ֻ�Ӣ����ĸ");
					jtf5.setForeground(Color.gray);
				}
				Pattern p1 = Pattern.compile("[\u4E00-\u9FA50-9a-zA-Z ]{0,200}");
				Matcher m1 = p1.matcher(id);
				flag3 = m1.matches();
				if (flag3 == false) {
					jle.setForeground(Color.red);
					jle.setText("סַ���Ϸ�");
				} else {
					jle.setForeground(Color.blue);
					jle.setText("סַ��ע��");

				}
			}

			@Override
			public void focusGained(FocusEvent e) {
				// TODO Auto-generated method stub
				
			}
		});
		jtf4.addFocusListener(new FocusListener() {

			@Override
			public void focusLost(FocusEvent e) {
				// TODO Auto-generated method stub
				id = jtf4.getText();
				if (id == "" || id == null) {
					jtf4.setText("������11λ������");
					jtf4.setForeground(Color.gray);
				}
				Pattern p1 = Pattern.compile("[0-9]{11}");
				Matcher m1 = p1.matcher(id);
				flag4 = m1.matches();
				if (flag4 == false) {
					jld.setForeground(Color.red);
					jld.setText("�绰���Ϸ�");
				} else {
					jld.setForeground(Color.blue);
					jld.setText("�绰��ע��");

				}
			}

			@Override
			public void focusGained(FocusEvent e) {
				// TODO Auto-generated method stub
			
			}
		});

		jtf1.addFocusListener(new FocusListener() {

			@Override
			public void focusLost(FocusEvent e) {
				// TODO Auto-generated method stub
				id = jtf1.getText();

				Pattern p1 = Pattern.compile("[0-9]{6,16}");
				Matcher m1 = p1.matcher(id);
				flag6 = m1.matches();
				if (flag6 == false) {
					jla.setForeground(Color.red);
					jla.setText("���Ų��Ϸ�");
				} else {
					String rpass = null;
					IUserInfoBiz ibz = new UserInfoBizImpl();
					rpass = ibz.findUser(id);
					if (rpass == null || rpass == "") {
						jla.setText("���ſ�ע��");
						jla.setForeground(Color.blue);
					} else {
						jla.setForeground(Color.red);
						jla.setText("�����Ѵ���");
					}
				}
			}

			@Override
			public void focusGained(FocusEvent e) {
				// TODO Auto-generated method stub
			
			}
		});
		jtf2.addFocusListener(new FocusListener() {

			@Override
			public void focusLost(FocusEvent e) {
				// TODO Auto-generated method stub

				id = jtf2.getText();
				Pattern p1 = Pattern.compile("[\u4E00-\u9FA5a-zA-Z]{2,15}");
				Matcher m1 = p1.matcher(id);
				flag5 = m1.matches();
				if (flag5 == false) {
					jlb.setForeground(Color.red);
					jlb.setText("�������Ϸ�");
				} else {
					jlb.setForeground(Color.blue);
					jlb.setText("������ע��");

				}

			}

			@Override
			public void focusGained(FocusEvent e) {
				// TODO Auto-generated method stub

			}
		});

		jb1.addActionListener(new ActionListener() {

			@Override
			public void actionPerformed(ActionEvent e) {
				// TODO Auto-generated method stub
				flag = jck1.isSelected();
				System.out.println("falg:" + flag);
				if (flag == true) {
					auth = 1;
				} else {
					auth = 0;
				}
				UserInfo user = new UserInfo();
				id = jtf1.getText();

				name = jtf2.getText();
				//password = String.valueOf(jpf.getPassword());
				tel = jtf4.getText();
				adress = jtf5.getText();

				user.setUserId(id);
				user.setUserName(name);
				user.setUserPassword(password);
				user.setTel(tel);
				user.setAdress(adress);
				user.setAuthority(auth);
				System.out.println(id + name + password + tel + adress + auth + "mm");
				IUserInfoBiz iuz = new UserInfoBizImpl();

				int row = 0;
				try {
					System.out.println(flag3);
					System.out.println(flag4);
					System.out.println(flag5);
					System.out.println(flag6);
					if (flag2&&flag3 && flag4 && flag5 && flag6) {
						
						row = iuz.update(up.id,user);
					} else {
						JOptionPane.showMessageDialog(jb1, "���ݲ��Ϸ���");
					}
					System.out.println(auth + "lll");
				} catch (Exception e1) {
					// TODO Auto-generated catch block
					e1.printStackTrace();
				}
				System.out.println("row:" + row);

				if (row > 0) {
					JOptionPane.showMessageDialog(jb1, "Ա���޸ĳɹ���");
					jf.dispose();
				} else {
					JOptionPane.showMessageDialog(jb1, "Ա���޸�ʧ�ܣ�");
				}
				// System.out.println(1);
			}
		});
		ImageIcon icon = new ImageIcon("image/timg.jpg");
		// ��ʾ����ͼ��
		jf.setIconImage(icon.getImage());
	}

}
