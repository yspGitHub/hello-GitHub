package com.ssy.view;

import java.awt.Color;
import java.awt.Font;
import java.awt.Toolkit;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.awt.event.ItemEvent;
import java.awt.event.ItemListener;
import java.util.Vector;

import javax.swing.ImageIcon;
import javax.swing.JButton;
import javax.swing.JComboBox;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JLayeredPane;
import javax.swing.JOptionPane;
import javax.swing.JPanel;
import javax.swing.JTextField;

import com.ssy.biz.IRoomBiz;
import com.ssy.biz.impl.RoomBizImpl;
import com.ssy.dao.TypeDao;
import com.ssy.entity.Room;

public class UpdateRoom {
	private JFrame jf;
	private JButton jb1;
	private JLabel jl1;
	private JLabel jl2;
	private JLabel jl3;
	private JLabel jl4;
	private JTextField jtf1;
	private JComboBox jcb2;
	private JComboBox jcb1;
	private JLayeredPane layeredPane=new JLayeredPane();
	private JPanel buttomJp;
	private JComboBox jcb3;
	private int typeInt;
	private String typeName;
	RoomPanel pr=new RoomPanel(1);
	TypeDao td=new TypeDao();
	public UpdateRoom(){
		init();
	}
	public void init(){
		jf=new JFrame("�޸ķ���");
		int width = (int)Toolkit.getDefaultToolkit().getScreenSize().getWidth();
		int height = (int)Toolkit.getDefaultToolkit().getScreenSize().getHeight();
		jf.setBounds((width-360)/2, (height-360)/2, 300, 300);
		jf.setLayout(null);
	//	jf.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		jf.setVisible(true);
		jl1=new JLabel("����:");
		jl1.setBounds(20,10,60,30);
		jl1.setFont(new Font("����", Font.BOLD, 16));//���������С
		jtf1=new JTextField();
		jtf1.setBounds(90, 10, 180, 30);
		jtf1.setFont(new Font("����",Font.BOLD,16));
		jtf1.setBackground(Color.gray);
		jtf1.setFocusable(false);
		jl2=new JLabel("¥��:");
		jl2.setBounds(20,60,60,30);
		jl2.setFont(new Font("����", Font.BOLD, 16));
		jcb1=new JComboBox<>();	
		jcb1.setBounds(90, 60, 180, 30);
		jb1=new JButton("�޸�");
		jb1.setBounds(110,210,120,40);
		jb1.setBackground(Color.white);
		jb1.setOpaque(false);
		jb1.setFont(new Font("����", Font.BOLD, 20));
		jl3=new JLabel("����:");
		jl3.setBounds(20,110,60,30);
		jl3.setFont(new Font("����", Font.BOLD, 16));
		jcb2=new JComboBox<>();	
		jcb2.setBounds(90, 110, 180, 30);
		layeredPane.add(jl2, JLayeredPane.MODAL_LAYER);
		layeredPane.add(jb1, JLayeredPane.MODAL_LAYER);
		layeredPane.add(jtf1, JLayeredPane.MODAL_LAYER);
		layeredPane.add(jcb2, JLayeredPane.MODAL_LAYER);
		layeredPane.add(jl3, JLayeredPane.MODAL_LAYER);
		layeredPane.add(jl1, JLayeredPane.MODAL_LAYER);
		layeredPane.add(jcb1, JLayeredPane.MODAL_LAYER);
		ImageIcon bc = new ImageIcon("image/b.jpg");
		buttomJp = new MyPanel(bc.getImage());
		buttomJp.setBounds(0, 0, 300, 260);
		layeredPane.add(buttomJp, JLayeredPane.DEFAULT_LAYER);	
		jf.setLayeredPane(layeredPane);
		jf.setVisible(true);
		
//		jf.add(jl1);
//		jf.add(jtf1);
//		jf.add(jl2);
//		jf.add(jcb1);
//		jf.add(jl3);
//		jf.add(jcb2);
//		//jf.add(jl4);
//		//jf.add(jcb3);
//		jf.add(jb1);
		jtf1.setText(pr.id);
		jtf1.setEditable(false);
		
		for(int i=1;i<30;i++){
			jcb1.addItem(i);
		}
		try {
			Vector<Vector> types=new Vector<Vector>();
			types=td.find();
			for(Vector type:types){
				
				jcb2.addItem(type.get(1));
				
			}
		}catch (Exception e) {
			// TODO: handle exception
			e.printStackTrace();
		}
IRoomBiz ibz=new RoomBizImpl();
		
		Vector<Vector> rooms=new Vector<Vector>();
		try {
			rooms=ibz.vagueFind(pr.id);
			for(Vector room :rooms){
				jcb1.setSelectedItem(room.get(1));
				typeName=room.get(2).toString();
				jcb2.setSelectedItem(typeName);
				
			
			}
		} catch (Exception e2) {
			// TODO Auto-generated catch block
			e2.printStackTrace();
		}
		Vector vt2=new Vector();
		System.out.println(jcb2.getSelectedItem().toString());
		try {
			vt2=td.query(typeName);
		} catch (Exception e1) {
			// TODO Auto-generated catch block
			e1.printStackTrace();
		}
		typeInt=(int) vt2.get(0);
		jcb2.addItemListener(new ItemListener(){

			@Override
			public void itemStateChanged(ItemEvent e) {
				// TODO Auto-generated method stub
				if(e.getStateChange()==ItemEvent.SELECTED){
					Vector vt2=new Vector();
					System.out.println(jcb2.getSelectedItem().toString());
					try {
						vt2=td.query(typeName);
					} catch (Exception e1) {
						// TODO Auto-generated catch block
						e1.printStackTrace();
					}
					typeInt=(int) vt2.get(0);
			
				}
			
				
			}
			
			
		});
		jb1.addActionListener(new ActionListener() {
			
			@Override
			public void actionPerformed(ActionEvent e) {
				// TODO Auto-generated method stub
				
				try {
				int row=ibz.update(pr.id,jcb1.getSelectedItem().toString(),String.valueOf(typeInt));
				if(row>0){
					JOptionPane.showMessageDialog(jb1, "�޸ĳɹ���");
					jf.dispose();
				}
				} catch (Exception e1) {
					// TODO Auto-generated catch block
					e1.printStackTrace();
				}
			}
		});
		
		ImageIcon icon = new ImageIcon("image/timg.jpg");
		//��ʾ����ͼ��
		jf.setIconImage(icon.getImage());
	
}
}