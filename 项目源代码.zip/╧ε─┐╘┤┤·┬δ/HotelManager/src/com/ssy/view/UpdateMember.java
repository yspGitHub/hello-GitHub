package com.ssy.view;

import java.awt.Color;
import java.awt.Font;
import java.awt.Toolkit;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.awt.event.ItemEvent;
import java.awt.event.ItemListener;
import java.util.Vector;

import javax.swing.ImageIcon;
import javax.swing.JButton;
import javax.swing.JComboBox;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JLayeredPane;
import javax.swing.JOptionPane;
import javax.swing.JPanel;
import javax.swing.JTextField;

import com.ssy.dao.MemberDao;
import com.ssy.entity.Member;
import com.ssy.entity.Vip;

public class UpdateMember {
	private JFrame jf;
	private JLabel jl1,jl2,jl3,jl4;
	private JTextField jtf1,jtf2,jtf3;
	private JButton jb1;
	private JComboBox jcb1;
	private String idCard,name,tel;
	private JLayeredPane layeredPane=new JLayeredPane();
	private JPanel buttomJp;
	private int vipId;
	Vector vmember;
	CustomerPanel cp=new CustomerPanel(1);
	public UpdateMember(){
		init();
	}

	private void init() {
		// TODO Auto-generated method stub
		// TODO Auto-generated method stub
		jf=new JFrame("�޸Ļ�Ա");
		int width = (int)Toolkit.getDefaultToolkit().getScreenSize().getWidth();
		int height = (int)Toolkit.getDefaultToolkit().getScreenSize().getHeight();
		jf.setBounds((width-360)/2, (height-360)/2, 320, 260);
		MemberDao md=new MemberDao();
		try {
			vmember=md.find(cp.id);
		} catch (Exception e1) {
			// TODO Auto-generated catch block
			e1.printStackTrace();
		}
		
		jf.setLayout(null);
		jf.setVisible(true);
		jl1=new JLabel("����:");
		jl1.setBounds(20,50,60,30);
		jl1.setFont(new Font("����", Font.BOLD, 16));//���������С
		jtf1=new JTextField();
		jtf1.setBounds(90, 50, 180, 30);
		jtf1.setBackground(new Color(149, 192, 247));
		jtf1.setFont(new Font("����",Font.BOLD,16));
		jl2=new JLabel("����֤:");
		jl2.setBounds(20,10,60,30);
		jl2.setFont(new Font("����", Font.BOLD, 16));//���������С
		jtf2=new JTextField();
		jtf2.setBounds(90, 10, 180, 30);
		jtf2.setFont(new Font("����",Font.BOLD,16));
		jtf2.setFocusable(false);
		jtf2.setBackground(Color.gray);

		jl3=new JLabel("�绰:");
		jl3.setBounds(20,90,60,30);
		jl3.setFont(new Font("����", Font.BOLD, 16));//���������С
		jtf3=new JTextField();
		jtf3.setBounds(90, 90, 180, 30);
		jtf3.setFont(new Font("����",Font.BOLD,16));
		jtf3.setBackground(new Color(149, 192, 247));
		jb1=new JButton("�޸�");
		jb1.setBounds(110,180,120,40);
		jb1.setOpaque(false);
		jl4=new JLabel("����:");
		jl4.setBounds(20,130,60,30);
		jl4.setFont(new Font("����", Font.BOLD, 16));//���������С
		jcb1=new JComboBox();
	
		jcb1.addItem("��ͨ��Ա");
		jcb1.addItem("�ƽ��Ա");
		jcb1.addItem("�׽��Ա");
		jcb1.setBounds(90,130,180,30);
	

		vipId=jcb1.getSelectedIndex()+1;
		jtf2.setText(cp.id);
		jtf2.setEditable(false);
		jtf1.setText(vmember.get(2).toString());
		jtf3.setText(vmember.get(3).toString());
		System.out.println(vmember.get(0).toString());
		System.out.println(vmember.get(0).toString().equals("�׽��Ա"));
		jcb1.setSelectedItem(vmember.get(0).toString());
		System.out.println(vipId);
		layeredPane.add(jl4, JLayeredPane.MODAL_LAYER);
		layeredPane.add(jl1, JLayeredPane.MODAL_LAYER);
		layeredPane.add(jtf1, JLayeredPane.MODAL_LAYER);
		layeredPane.add(jl2, JLayeredPane.MODAL_LAYER);
		layeredPane.add(jb1, JLayeredPane.MODAL_LAYER);
		layeredPane.add(jtf2, JLayeredPane.MODAL_LAYER);
		layeredPane.add(jl3, JLayeredPane.MODAL_LAYER);
		
		layeredPane.add(jtf3, JLayeredPane.MODAL_LAYER);
		layeredPane.add(jcb1, JLayeredPane.MODAL_LAYER);
		ImageIcon bc = new ImageIcon("image/b.jpg");
		
		buttomJp = new MyPanel(bc.getImage());
		buttomJp.setBounds(0, 0, 320, 260);
		layeredPane.add(buttomJp, JLayeredPane.DEFAULT_LAYER);	
		jf.setLayeredPane(layeredPane);
		jf.setVisible(true);
//		jf.add(jl1);
//		jf.add(jtf1);
//		jf.add(jl2);
//		jf.add(jtf2);
//		jf.add(jl3);
//		jf.add(jtf3);
//		jf.add(jl4);
//		jf.add(jcb1);
//		jf.add(jb1);
		
		
		jb1.addActionListener(new ActionListener() {

			@Override
			public void actionPerformed(ActionEvent e) {
				// TODO Auto-generated method stub
				idCard=jtf2.getText();
				name=jtf1.getText();
				tel=jtf3.getText();
					MemberDao md=new MemberDao();
					Vip vip=new Vip();
					vip.setId(vipId);
					Member member=new Member();
					member.setId(idCard);
					member.setName(name);
					member.setTel(tel);
					member.setVip(vip);
					int row=0;
					row=md.update(cp.id, member);
					if(row>0){
						JOptionPane.showMessageDialog(jb1, "��Աע��ɹ���");
						jf.dispose();
					}else{
						JOptionPane.showMessageDialog(jb1, "��Աע��ʧ�ܣ�");
					}
			}
			
			
		});
		jcb1.addItemListener(new ItemListener() {
			
			@Override
			public void itemStateChanged(ItemEvent e) {
				// TODO Auto-generated method stub
				if(e.getStateChange()==ItemEvent.SELECTED){
				vipId=jcb1.getSelectedIndex()+1;
				System.out.println(vipId);
				}
			}
		});
		ImageIcon icon = new ImageIcon("image/timg.jpg");
		//��ʾ����ͼ��
		jf.setIconImage(icon.getImage());
	}

}
