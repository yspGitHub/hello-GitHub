package com.ssy.view;

import java.awt.Color;
import java.awt.Component;
import java.awt.Dimension;
import java.awt.Font;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.awt.event.ItemEvent;
import java.awt.event.ItemListener;
import java.awt.event.KeyEvent;
import java.awt.event.KeyListener;
import java.awt.event.MouseEvent;
import java.awt.event.MouseListener;
import java.util.Vector;

import javax.swing.JButton;
import javax.swing.JComboBox;
import javax.swing.JLabel;
import javax.swing.JOptionPane;
import javax.swing.JPanel;
import javax.swing.JScrollPane;
import javax.swing.JTable;
import javax.swing.JTextField;
import javax.swing.SwingConstants;
import javax.swing.table.DefaultTableCellRenderer;
import javax.swing.table.DefaultTableModel;
import javax.swing.table.JTableHeader;
import javax.swing.table.TableCellRenderer;

import com.ssy.dao.CustomerDao;
import com.ssy.dao.MemberDao;

public class CustomerPanel extends JPanel {
	private JButton jb1, jb2, jb3, jb4, jb5, jb6, jb7, jb8, jb9,jba;
	private JComboBox jcb1, jcb2, jcb3, jcb4, jcb5;
	private JLabel jl1;
	private JTextField jtx1;

	Vector title;
	public static String id;
	private String sName = "�����ͻ�", info;
	DefaultTableModel tableModel = new DefaultTableModel();
	JScrollPane jsp;
	private JTable jt;
	Vector<Vector> vector;
	CustomerDao cd = new CustomerDao();

	public void initFindOrd() {
		vector = new Vector<Vector>();
		title = new Vector();

		title.add("����");
		title.add("�绰");
		title.add("����");
		title.add("����ʱ��");

		tableModel.setDataVector(vector, title);
	}

	public void initFindMe() {
		vector = new Vector<Vector>();
		title = new Vector();
		title.add("����֤");
		title.add("����");
		title.add("�绰");
		title.add("�ȼ�");
		title.add("����");
		MemberDao md = new MemberDao();
		try {
			vector = md.find();

			System.out.println(vector.size() + "adf");
		} catch (Exception e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		tableModel.setDataVector(vector, title);
		jt.getColumnModel().getColumn(0).setPreferredWidth(200);
		// jt.getColumnModel().getColumn(6).setPreferredWidth(200);
	}

	public void initFindCus() {
		this.setOpaque(false);
		vector = new Vector<Vector>();
		title = new Vector();
		title.add("����֤");
		title.add("����");
		title.add("�绰");
		title.add("����");
		title.add("�ȼ�");
		title.add("����ʱ��");
		title.add("��ֹʱ��");
		try {
			vector = cd.find();
		} catch (Exception e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		
		tableModel.setDataVector(vector, title);
		jt.getColumnModel().getColumn(0).setPreferredWidth(200);
		jt.getColumnModel().getColumn(2).setPreferredWidth(150);
	}

	public CustomerPanel() {
		init();
	}

	public CustomerPanel(int i) {

	}

	private void init() {
		// TODO Auto-generated method stub

		jcb1 = new JComboBox();
		jcb1.setBounds(12, 10, 150, 30);
		jcb1.addItem("�����ͻ�");

		jcb1.addItem("��Ա�б�");
		jb1 = new JButton("ע���Ա");
		jb1.setBounds(1000, 80, 120, 40);
		jb1.setBackground(Color.white);
		jb1.setOpaque(false);
		jb1.setForeground(Color.black);
		jb1.setFont(new Font("����", Font.BOLD, 20));
		jb1.setFocusPainted(false);
		jb2 = new JButton("ɾ����Ա");
		jb2.setBounds(1000, 170, 120, 40);
		jb2.setEnabled(false);
		jb2.setBackground(Color.white);
		jb2.setOpaque(false);
		jb2.setForeground(Color.black);
		jb2.setFont(new Font("����", Font.BOLD, 20));
		jb2.setFocusPainted(false);
		jb3 = new JButton("�޸Ļ�Ա");
		jb3.setBounds(1000, 260, 120, 40);
		jb3.setEnabled(false);
		jb3.setBackground(Color.white);
		jb3.setOpaque(false);
		jb3.setForeground(Color.black);
		jb3.setFont(new Font("����", Font.BOLD, 20));
		jb3.setFocusPainted(false);
		jba=new JButton("ˢ��");
		jba.setBounds(1000, 30, 120, 40);
		jba.setBackground(Color.white);
		jba.setOpaque(false);
		jba.setForeground(Color.black);
		jba.setFont(new Font("����", Font.BOLD, 20));
		jba.setFocusPainted(false);
		// jb3=new JButton("����ԤԼ");
		// jb3.setBounds(700, 60, 90, 30);
		// jb8=new JButton("ɾ��ԤԼ");
		// jb8.setBounds(700, 100, 90, 30);
		//
		// jb9=new JButton("�޸�ԤԼ");
		// jb9.setBounds(700, 140, 90, 30);
		jl1 = new JLabel("��ѯ:");
		jl1.setFont(new Font("����", Font.BOLD, 20));
		jl1.setBounds(200, 10, 90, 30);
		jtx1 = new JTextField();
		jtx1.setBounds(260, 10, 150, 30);
		jtx1.setOpaque(false);
		jt = new JTable() {
			public boolean isCellEditable(int row, int column) {
				return false;
			}
		};
		DefaultTableCellRenderer render = new DefaultTableCellRenderer() {
			public Component getTableCellRendererComponent(JTable table, Object value, boolean isSelected,
					boolean hasFocus, int row, int column) {
				// setOpaque(false);
				// jt.setCellSelectionEnabled(false);
				// jt.setSelectionMode(ListSelectionModel.SINGLE_INTERVAL_SELECTION);
				setOpaque(false);
				jt.setSelectionForeground(Color.black);
				if (isSelected) {
					if (row == jt.getSelectedRow()) {
						setOpaque(true);
						jt.setSelectionForeground(Color.white);

					}
				}

				return super.getTableCellRendererComponent(jt, value, true, false, row, column);
			}
		};
		jt.setSelectionBackground(new Color(149, 192, 247));

		render.setOpaque(false);

		jt.setDefaultRenderer(Object.class, render);

		jt.getTableHeader().setReorderingAllowed(false);
		jt.setModel(tableModel);
		jt.validate();

		jt.setOpaque(false);

		jsp = new JScrollPane();
		jt.setFont(new Font("����", Font.BOLD, 20));
		jt.setRowHeight(25);
		jt.getTableHeader().setFont(new Font("����", Font.BOLD, 20));
		jsp.getViewport().setOpaque(false);// ��JScrollPane����Ϊ͸��
		jsp.setOpaque(false);// ���м��viewport����Ϊ͸��
		jsp.setViewportView(jt);// װ�ر���
		jsp.setColumnHeaderView(jt.getTableHeader());// ����ͷ����HeaderView���֣�
		jsp.getColumnHeader().setOpaque(false);// ��ȡ��ͷ����������Ϊ͸��

		jt.getTableHeader().setReorderingAllowed(false);
		jt.setDefaultRenderer(Object.class, render);

		JTableHeader header = jt.getTableHeader();// ��ȡͷ��
		header.setPreferredSize(new Dimension(30, 26));
		header.setOpaque(false);// ����ͷ��Ϊ͸��
		header.getTable().setOpaque(false);// ����ͷ������ı���͸��
		header.setDefaultRenderer(new HeaderCellRenderer());
		TableCellRenderer headerRenderer = header.getDefaultRenderer();
		if (headerRenderer instanceof JLabel) {
			((JLabel) headerRenderer).setHorizontalAlignment(JLabel.CENTER);
			((JLabel) headerRenderer).setOpaque(false);
		}

		jsp.setBounds(10, 80, 930, 440);
		this.setBounds(0, 0, 900, 400);
		this.setLayout(null);
		this.add(jcb1);
		this.add(jl1);
		this.add(jtx1);
		this.add(jb1);
		this.add(jb2);
		this.add(jb3);
		// this.add(jb7);
		// this.add(jb8);
		// this.add(jb9);
		this.add(jba);
		this.add(jsp);

		this.setVisible(true);
		initFindCus();

		jcb1.addItemListener(new ItemListener() {

			@Override
			public void itemStateChanged(ItemEvent e) {
				// TODO Auto-generated method stub
				sName = jcb1.getSelectedItem().toString();
				if (sName.equals("�����ͻ�")) {
					initFindCus();
					jb2.setEnabled(false);
					jb3.setEnabled(false);
				}
				if (sName.equals("��Ա�б�")) {
					initFindMe();

				}
				if (sName.equals("ԤԼ�ͻ�")) {

				}
			}
		});
		jba.addActionListener(new ActionListener() {
			
			@Override
			public void actionPerformed(ActionEvent e) {
				// TODO Auto-generated method stub
				sName = jcb1.getSelectedItem().toString();
				if (sName.equals("�����ͻ�")) {
					initFindCus();
					jtx1.setText("");
				}
				if (sName.equals("��Ա�б�")) {
					initFindMe();
					jtx1.setText("");

				}
			}
		});
		jtx1.addKeyListener(new KeyListener() {

			@Override
			public void keyTyped(KeyEvent e) {
				// TODO Auto-generated method stub

			}

			@Override
			public void keyReleased(KeyEvent e) {
				// TODO Auto-generated method stub
				if (sName.equals("�����ͻ�")) {
					vector = new Vector<Vector>();
					
					title = new Vector();
					info = jtx1.getText();
					title.add("����֤");
					title.add("����");
					title.add("�绰");
					title.add("����");
					title.add("�ȼ�");
					title.add("����ʱ��");
					title.add("��ֹʱ��");
					try {
						vector = cd.mfind(info);
			
					} catch (Exception e1) {
						// TODO Auto-generated catch block
						e1.printStackTrace();
					}
					tableModel.setDataVector(vector, title);
					jt.getColumnModel().getColumn(0).setPreferredWidth(200);
			
					jt.getColumnModel().getColumn(2).setPreferredWidth(150);
				}
				if (sName.equals("��Ա�б�")) {

					vector = new Vector<Vector>();
					title = new Vector();
					title.add("����֤");
					title.add("����");
					title.add("�绰");
					title.add("�ȼ�");
					title.add("����");

					MemberDao md = new MemberDao();
					try {
						info = jtx1.getText();
						System.out.println(info + "adad");
						vector = md.mfind(info);
						System.out.println(vector.size() + "kk");

					} catch (Exception e1) {
						// TODO Auto-generated catch block
						e1.printStackTrace();
					}

					tableModel.setDataVector(vector, title);
					jt.getColumnModel().getColumn(0).setPreferredWidth(200);

				}
				if (sName.equals("ԤԼ�ͻ�")) {

				}

			}

			@Override
			public void keyPressed(KeyEvent e) {
				// TODO Auto-generated method stub

			}
		});
		jb1.addActionListener(new ActionListener() {

			@Override
			public void actionPerformed(ActionEvent e) {
				// TODO Auto-generated method stub
				new InsertMember();
			}
		});
		// jb7.addActionListener(new ActionListener() {
		//
		// @Override
		// public void actionPerformed(ActionEvent e) {
		// // TODO Auto-generated method stub
		// new InsertOrder();
		// }
		// });
		jt.addMouseListener(new MouseListener() {

			@Override
			public void mouseReleased(MouseEvent e) {
				// TODO Auto-generated method stub

			}

			@Override
			public void mousePressed(MouseEvent e) {
				// TODO Auto-generated method stub

			}

			@Override
			public void mouseExited(MouseEvent e) {
				// TODO Auto-generated method stub

			}

			@Override
			public void mouseEntered(MouseEvent e) {
				// TODO Auto-generated method stub

			}

			@Override
			public void mouseClicked(MouseEvent e) {
				// TODO Auto-generated method stub
				int row = jt.getSelectedRow();
				id = jt.getValueAt(row, 0).toString();
				if (sName.equals("��Ա�б�")) {
					jb2.setEnabled(true);
					jb3.setEnabled(true);
				}
				System.out.println(id);
			}
		});
		jb2.addActionListener(new ActionListener() {

			@Override
			public void actionPerformed(ActionEvent e) {
				// TODO Auto-generated method stub
				if (sName.equals("��Ա�б�")) {
					int row = 0;
					MemberDao md = new MemberDao();
					int del = JOptionPane.showConfirmDialog(jb2, "��ȷ��Ҫɾ��" + id + "�Ż�Ա��", "����",
							JOptionPane.YES_NO_OPTION, JOptionPane.QUESTION_MESSAGE);
					if (del == JOptionPane.YES_OPTION) {
						row = md.delete(id);
						initFindMe();
					} else {
						return;
					}
					if (row > 0) {
						JOptionPane.showMessageDialog(jb2, "ɾ���ɹ���");
					}
				}
			}
		});
		jb3.addActionListener(new ActionListener() {

			@Override
			public void actionPerformed(ActionEvent e) {
				// TODO Auto-generated method stub
				if (sName.equals("��Ա�б�")) {
					new UpdateMember();
				}
			}
		});
	}
}
