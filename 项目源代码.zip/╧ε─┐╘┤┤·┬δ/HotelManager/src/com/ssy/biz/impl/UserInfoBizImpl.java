package com.ssy.biz.impl;

import java.util.List;
import java.util.Vector;

import com.ssy.biz.IUserInfoBiz;
import com.ssy.dao.IUserInfoDao;
import com.ssy.dao.impl.UserInfoDaoImpl;
import com.ssy.entity.UserInfo;

public class UserInfoBizImpl implements IUserInfoBiz{
	IUserInfoDao userdao=new UserInfoDaoImpl();
	@Override
	public int insert(UserInfo user) {
		// TODO Auto-generated method stub
		
		return userdao.insert(user);
	}

	@Override
	public Vector<Vector> seek() {
		// TODO Auto-generated method stub
		return userdao.seek();
		
	}

	

	@Override
	public List<UserInfo> login(String username, String password) {
		// TODO Auto-generated method stub
		return userdao.login(username, password);
	}

	@Override
	public int update(String id, String password){
		// TODO Auto-generated method stub
		return userdao.update(id, password);
	}

	@Override
	public int delete(String id) {
		// TODO Auto-generated method stub
		return userdao.delete(id);
	}

	@Override
	public String findPass(String id) {
		// TODO Auto-generated method stub
		return userdao.findPass(id);
	}

	@Override
	public String findUser(String id) {
		// TODO Auto-generated method stub
		return userdao.findUser(id);
	}

	@Override
	public Vector<Vector> mfind(String info) {
		// TODO Auto-generated method stub
		return userdao.mfind(info);
	}

	@Override
	public Vector seek(String id) {
		// TODO Auto-generated method stub
		return userdao.seek(id);
	}

	@Override
	public int update(String id, UserInfo user) {
		// TODO Auto-generated method stub
		return userdao.update(id, user);
	}

}
