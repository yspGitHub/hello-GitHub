package com.ssy.biz.impl;

import java.util.Vector;

import com.ssy.biz.IRoomBiz;
import com.ssy.dao.IRoomDao;
import com.ssy.dao.impl.RoomDaoImpl;
import com.ssy.entity.Room;

public class RoomBizImpl implements IRoomBiz{
	
	IRoomDao ird=new RoomDaoImpl();
	@Override
	public int insert(Room room) throws Exception {
		// TODO Auto-generated method stub
		
		return ird.insert(room);
	}

	@Override
	public Vector<Vector> find(String stateName) throws Exception {
		// TODO Auto-generated method stub
		return ird.find(stateName);
	}

	@Override
	public int update(String id,String floor,String type) throws Exception {
		// TODO Auto-generated method stub
		return ird.update(id, floor, type);
	}

	@Override
	public int delete(String id) throws Exception {
		// TODO Auto-generated method stub
	return ird.delete(id);
	}

	@Override
	public int openRoom(String id,String roomState) throws Exception {
		// TODO Auto-generated method stub
		return ird.openRoom(id,roomState);
	}

	@Override
	public Vector<Vector> vagueFind(String id) throws Exception {
		// TODO Auto-generated method stub
		return ird.vagueFind(id);
	}

	@Override
	public Vector<Vector> typeFind(String typeName) throws Exception {
		// TODO Auto-generated method stub
		return ird.typeFind(typeName);
	}

	@Override
	public Vector<Vector> find() throws Exception {
		// TODO Auto-generated method stub
		return ird.find();
	}

	@Override
	public Vector<Vector> typeFind() throws Exception {
		// TODO Auto-generated method stub
		return ird.typeFind();
	}

	@Override
	public Vector<Vector> find(String stateName, String typeName) throws Exception {
		// TODO Auto-generated method stub
		System.out.println(111);
		return ird.find(stateName,typeName);
	}

}
