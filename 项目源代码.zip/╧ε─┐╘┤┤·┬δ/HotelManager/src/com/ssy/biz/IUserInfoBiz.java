package com.ssy.biz;

import java.util.List;
import java.util.Vector;

import com.ssy.entity.UserInfo;

public interface IUserInfoBiz {
	  public int insert(UserInfo user);
	  public int update(String id,UserInfo user);
	  public Vector<Vector> seek();
	  public Vector seek(String id);
	  public int update(String id,String password);
	  public List<UserInfo> login(String username,String password);
	  public int delete(String id);
	  public String findPass(String id);
	  public String findUser(String id);
	  public Vector<Vector> mfind(String info);
}
