/**
 * 
 */
/**
 * @author Administrator
 *
 */
package com.ssy.entity;