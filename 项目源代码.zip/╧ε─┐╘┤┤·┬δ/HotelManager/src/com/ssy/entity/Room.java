package com.ssy.entity;

public class Room {
	private String Id;
	private int type;
	private	int flower;
	private String sate;
	private int tel;
	public String getId() {
		return Id;
	}
	public void setId(String id) {
		Id = id;
	}
	public int getType() {
		return type;
	}
	public void setType(int type) {
		this.type = type;
	}
	public int getFlower() {
		return flower;
	}
	public void setFlower(int flower) {
		this.flower = flower;
	}
	public String getSate() {
		return sate;
	}
	public void setSate(String sate) {
		this.sate = sate;
	}
	public int getTel() {
		return tel;
	}
	public void setTel(int tel) {
		this.tel = tel;
	}
}
