package com.ssy.entity;

public class Member {
	private String id;
	private Vip vip;
	private String tel;
	private String name;
	private int integration;
	public String getId() {
		return id;
	}
	public void setId(String id) {
		this.id = id;
	}
	public Vip getVip() {
		return vip;
	}
	public void setVip(Vip vip) {
		this.vip = vip;
	}


	
	public String getTel() {
		return tel;
	}
	public void setTel(String tel) {
		this.tel = tel;
	}
	public String getName() {
		return name;
	}
	public void setName(String name) {
		this.name = name;
	}
	public int getIntegration() {
		return integration;
	}
	public void setIntegration(int integration) {
		this.integration = integration;
	}
}
