/*
SQLyog 企业版 - MySQL GUI v8.14 
MySQL - 5.5.42-log : Database - hotel
*********************************************************************
*/

/*!40101 SET NAMES utf8 */;

/*!40101 SET SQL_MODE=''*/;

/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;
CREATE DATABASE /*!32312 IF NOT EXISTS*/`hotel` /*!40100 DEFAULT CHARACTER SET utf8 */;

USE `hotel`;

/*Table structure for table `master` */

DROP TABLE IF EXISTS `master`;

CREATE TABLE `master` (
  `id` int(4) NOT NULL,
  `uname` varchar(4) DEFAULT NULL,
  `upassword` varchar(6) DEFAULT NULL,
  `money` int(4) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

/*Data for the table `master` */

/*Table structure for table `tb_customer` */

DROP TABLE IF EXISTS `tb_customer`;

CREATE TABLE `tb_customer` (
  `cus_id` varchar(18) NOT NULL,
  `cus_name` varchar(20) NOT NULL,
  `cus_tel` varchar(15) NOT NULL,
  `cus_room` varchar(20) NOT NULL,
  `cus_vip` int(1) NOT NULL,
  `cus_order` varchar(20) DEFAULT NULL,
  `cus_open` varchar(20) DEFAULT NULL,
  `cus_leave` varchar(20) DEFAULT NULL,
  PRIMARY KEY (`cus_id`),
  KEY `FK_CUSTOMER` (`cus_room`),
  KEY `fk_vip` (`cus_vip`),
  CONSTRAINT `FK_CUSTOMER` FOREIGN KEY (`cus_room`) REFERENCES `tb_room` (`room_id`),
  CONSTRAINT `fk_vip` FOREIGN KEY (`cus_vip`) REFERENCES `tb_vip` (`vip_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

/*Data for the table `tb_customer` */

insert  into `tb_customer`(`cus_id`,`cus_name`,`cus_tel`,`cus_room`,`cus_vip`,`cus_order`,`cus_open`,`cus_leave`) values ('36012119970128393X','樊启望','13006208762','109',3,NULL,'2017-7-11','2017-7-14'),('36012119970128394X','樊启望','13006208761','888',4,NULL,'2017-7-12','2017-7-15'),('36012119980128393X','大苏打','11111111111','301',4,NULL,'2017-7-12','2017-7-14'),('360125197808089999','范菲菲','11111111111','108',4,NULL,'2017-7-12','2017-7-14'),('360725123455555123','方芳芳','11111111111','102',4,NULL,'2017-7-12','2017-7-17');

/*Table structure for table `tb_log` */

DROP TABLE IF EXISTS `tb_log`;

CREATE TABLE `tb_log` (
  `log_id` int(100) NOT NULL AUTO_INCREMENT,
  `log_time` varchar(30) NOT NULL,
  `log_option` varchar(20) NOT NULL,
  `log_room` varchar(10) NOT NULL,
  `log_cus` varchar(19) NOT NULL,
  `log_money` varchar(20) DEFAULT NULL,
  `log_user` varchar(15) DEFAULT NULL,
  PRIMARY KEY (`log_id`)
) ENGINE=InnoDB AUTO_INCREMENT=152 DEFAULT CHARSET=utf8;

/*Data for the table `tb_log` */

insert  into `tb_log`(`log_id`,`log_time`,`log_option`,`log_room`,`log_cus`,`log_money`,`log_user`) values (55,'2017-7-7 23:27:50','开房','103','36012119970128393x','836','0100110'),(56,'2017-7-7 23:29:43','开房','209','219221929119','6000',NULL),(57,'2017-7-8 8:37:12','开房','109','360481199805040026','198','0100110'),(58,'2017-7-8 9:4:37','开房','105','1111','440',NULL),(59,'2017-7-8 9:3:12','退房','105','1111','',NULL),(60,'2017-7-8 9:12:44','退房','209','219221929119','','12345678'),(61,'2017-7-8 9:38:54','开房','202','360725123321321321','95','0100110'),(62,'2017-7-8 9:29:0','退房','202','360725123321321321','','0100110'),(63,'2017-7-8 10:18:3','退房','103','36012119970128393x','','12345678'),(64,'2017-7-8 10:18:3','退房','109','360481199805040026','','12345678'),(65,'2017-7-8 10:24:58','开房','888','36012119970128393X','11400','12345678'),(66,'2017-7-8 10:59:29','退房','888','36012119970128393X','',NULL),(67,'2017-7-8 15:55:12','开房','206','360725123321321321','418','1008611'),(68,'2017-7-8 15:59:0','开房','709','36012119970128393X','209','0100110'),(69,'2017-7-8 15:59:51','开房','709','000','220','0100110'),(70,'2017-7-8 16:0:30','开房','102','00000','120','0100110'),(71,'2017-7-8 16:0:50','开房','301','11','200','0100110'),(72,'2017-7-8 16:2:2','开房','108','923123','120','0100110'),(73,'2017-7-8 16:3:51','退房','102','00000','','0100110'),(74,'2017-7-8 16:4:17','退房','108','923123','','0100110'),(75,'2017-7-8 16:4:43','退房','102','','','0100110'),(76,'2017-7-8 16:5:8','退房','206','360725123321321321','','0100110'),(77,'2017-7-8 16:5:8','退房','102','','','0100110'),(78,'2017-7-8 16:5:8','退房','102','','','0100110'),(79,'2017-7-8 16:5:8','退房','102','','','0100110'),(80,'2017-7-8 16:5:8','退房','102','','','0100110'),(81,'2017-7-9 9:1:4','退房','108','','','0100110'),(82,'2017-7-9 9:1:4','退房','108','','','0100110'),(83,'2017-7-9 9:1:4','退房','108','','','0100110'),(84,'2017-7-9 10:22:22','退房','108','','','0100110'),(85,'2017-7-9 11:45:14','退房','108','','',NULL),(86,'2017-7-9 11:45:14','退房','709','000','',NULL),(87,'2017-7-9 12:20:46','退房','301','11','',NULL),(88,'2017-7-9 16:26:21','退房','301','','',NULL),(89,'2017-7-9 17:1:23','开房','106','36012119970128393X','190',NULL),(90,'2017-7-9 20:19:46','退房','301','','',NULL),(91,'2017-7-10 8:58:2','退房','106','36012119970128393X','',NULL),(92,'2017-7-10 10:14:15','开房','102','36012119970128393X','228',NULL),(93,'2017-7-10 10:23:31','退房','102','36012119970128393X','',NULL),(94,'2017-7-10 11:26:1','退房','206','','','0100110'),(95,'2017-7-10 11:41:47','退房','206','','',NULL),(96,'2017-7-10 11:41:47','退房','206','','',NULL),(97,'2017-7-10 11:41:47','退房','301','','',NULL),(98,'2017-7-10 11:46:8','开房','103','36012119970128393X','209',NULL),(99,'2017-7-10 11:41:47','退房','103','36012119970128393X','',NULL),(100,'2017-7-10 11:41:47','退房','103','','',NULL),(101,'2017-7-10 11:50:3','开房','111','36012119970128393X','209',NULL),(102,'2017-7-10 11:49:33','退房','111','36012119970128393X','',NULL),(103,'2017-7-10 14:11:42','开房','206','36012119970128393X','769',NULL),(104,'2017-7-10 14:12:33','退房','206','36012119970128393X','',NULL),(105,'2017-7-10 14:14:3','开房','888','36012119970128393X','11400',NULL),(106,'2017-7-10 14:17:19','退房','888','36012119970128393X','',NULL),(107,'2017-7-10 14:17:50','开房','103','36012119970128393X','1026',NULL),(108,'2017-7-10 14:18:51','退房','103','36012119970128393X','',NULL),(109,'2017-7-10 14:19:25','开房','809','36012119970128393X','589',NULL),(110,'2017-7-10 14:21:56','退房','809','36012119970128393X','',NULL),(111,'2017-7-10 14:22:41','开房','102','36012119970128393X','912',NULL),(112,'2017-7-10 14:23:14','退房','102','36012119970128393X','',NULL),(113,'2017-7-10 14:23:48','开房','108','36012119970128393X','608',NULL),(114,'2017-7-10 14:26:19','退房','108','36012119970128393X','',NULL),(115,'2017-7-10 14:27:5','开房','103','36012119970128393X','1795',NULL),(116,'2017-7-10 14:28:39','退房','103','36012119970128393X','',NULL),(117,'2017-7-10 14:29:29','开房','109','36012119970128393X','972',NULL),(118,'2017-7-11 8:52:41','退房','109','36012119970128393X','','0100110'),(119,'2017-7-11 8:59:39','开房','111','36012119970128393x','1215','0100110'),(120,'2017-7-11 9:3:25','退房','111','36012119970128393x','','0100110'),(121,'2017-7-11 9:6:1','开房','809','36012119970128393X','837','0100110'),(122,'2017-7-11 9:13:58','退房','809','36012119970128393X','','0100110'),(123,'2017-7-11 9:14:54','开房','888','36012119970128393x','10800','0100110'),(124,'2017-7-11 9:15:50','退房','888','36012119970128393x','','0100110'),(125,'2017-7-11 9:16:49','开房','301','36012119970128393x','720','0100110'),(126,'2017-7-11 9:22:49','退房','301','36012119970128393x','','0100110'),(127,'2017-7-11 9:24:13','开房','301','36012119970128393X','900','0100110'),(128,'2017-7-11 9:24:51','退房','301','36012119970128393X','','0100110'),(129,'2017-7-11 9:25:30','开房','301','36012119970128393X','900','0100110'),(130,'2017-7-11 9:27:26','退房','301','36012119970128393X','','0100110'),(131,'2017-7-11','开房','206','36012119970128393X','1458','0100110'),(132,'2017-7-11 9:52:36','退房','206','36012119970128393X','','0100110'),(133,'2017-7-11','开房','301','36012119970128393X','180','0100110'),(134,'2017-7-11','开房','103','360121199701283931','810','0100110'),(135,'2017-7-11','开房','102','360121199701283932','320','0100110'),(136,'2017-7-11 14:38:33','退房','301','36012119970128393X','','0100110'),(137,'2017-7-11 14:38:33','退房','102','360121199701283932','','0100110'),(138,'2017-7-11 14:38:33','退房','103','360121199701283931','','0100110'),(139,'2017-7-11','开房','888','36012119970128393X','2940','0100110'),(140,'2017-7-11 16:1:48','退房','888','36012119970128393X','','0100110'),(141,'2017-7-11','开房','888','36012119970128393X','2700','0100110'),(142,'2017-7-11 16:1:48','退房','888','36012119970128393X','','0100110'),(143,'2017-7-11','开房','301','36012119970128393X','180','0100110'),(144,'2017-7-11 16:4:16','退房','301','36012119970128393X','','0100110'),(145,'2017-7-11','开房','301','36012119970128393X','540','0100110'),(146,'2017-7-11 16:5:42','退房','301','36012119970128393X','','0100110'),(147,'2017-7-11','开房','109','36012119970128393X','729',NULL),(148,'2017-7-12','开房','888','36012119970128394X','9000','0100110'),(149,'2017-7-12','开房','301','36012119980128393X','400','0100110'),(150,'2017-7-12','开房','102','360725123455555123','800','0100110'),(151,'2017-7-12','开房','108','360125197808089999','320','0100110');

/*Table structure for table `tb_member` */

DROP TABLE IF EXISTS `tb_member`;

CREATE TABLE `tb_member` (
  `me_id` varchar(20) NOT NULL,
  `me_vip` int(1) NOT NULL,
  `me_tel` varchar(11) NOT NULL,
  `me_name` varchar(20) NOT NULL,
  `me_integration` int(10) DEFAULT NULL,
  PRIMARY KEY (`me_id`),
  KEY `fk_member` (`me_vip`),
  CONSTRAINT `fk_member` FOREIGN KEY (`me_vip`) REFERENCES `tb_vip` (`vip_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

/*Data for the table `tb_member` */

insert  into `tb_member`(`me_id`,`me_vip`,`me_tel`,`me_name`,`me_integration`) values ('101103198908093960',2,'119120119','韩梅梅',0),('36012119970128393X',3,'13006208762','樊启望',1040),('360481199805040026',3,'3147483647','施思伊',20),('360725123321321321',1,'1231231232','黄颖菲',30);

/*Table structure for table `tb_order` */

DROP TABLE IF EXISTS `tb_order`;

CREATE TABLE `tb_order` (
  `or_id` int(11) NOT NULL AUTO_INCREMENT,
  `or_name` varchar(10) NOT NULL,
  `or_tel` int(12) NOT NULL,
  `or_type` varchar(20) NOT NULL,
  PRIMARY KEY (`or_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

/*Data for the table `tb_order` */

/*Table structure for table `tb_room` */

DROP TABLE IF EXISTS `tb_room`;

CREATE TABLE `tb_room` (
  `room_id` varchar(20) NOT NULL,
  `room_flower` int(2) NOT NULL,
  `room_type` int(1) NOT NULL,
  `room_state` varchar(10) NOT NULL,
  `room_tel` varchar(11) NOT NULL,
  PRIMARY KEY (`room_id`),
  KEY `fk_type_id` (`room_type`),
  CONSTRAINT `fk_type_id` FOREIGN KEY (`room_type`) REFERENCES `tb_type` (`type_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

/*Data for the table `tb_room` */

insert  into `tb_room`(`room_id`,`room_flower`,`room_type`,`room_state`,`room_tel`) values ('101',1,3,'未开房','8989'),('102',1,3,'开房中','8990'),('103',1,2,'未开房','8991'),('108',1,3,'开房中','8996'),('109',1,2,'开房中','222222'),('111',1,2,'未开房','8999'),('126',1,2,'未开房','9014'),('222',2,2,'未开房','9110'),('235',2,2,'未开房','9123'),('238',2,10,'未开房','9126'),('301',3,7,'开房中','9189'),('809',8,10,'未开房','9697'),('888',8,5,'开房中','9776'),('999',9,5,'未开房','9887');

/*Table structure for table `tb_type` */

DROP TABLE IF EXISTS `tb_type`;

CREATE TABLE `tb_type` (
  `type_id` int(1) NOT NULL AUTO_INCREMENT,
  `type_name` varchar(20) NOT NULL,
  `type_price` int(10) NOT NULL,
  PRIMARY KEY (`type_id`)
) ENGINE=InnoDB AUTO_INCREMENT=11 DEFAULT CHARSET=utf8;

/*Data for the table `tb_type` */

insert  into `tb_type`(`type_id`,`type_name`,`type_price`) values (2,'豪华大床房',270),(3,'标间',160),(5,'总统套房',3000),(7,'麻将房',200),(10,'商务标间',310);

/*Table structure for table `tb_user` */

DROP TABLE IF EXISTS `tb_user`;

CREATE TABLE `tb_user` (
  `user_id` varchar(20) NOT NULL,
  `user_name` varchar(10) NOT NULL,
  `user_password` varchar(20) NOT NULL,
  `user_authority` int(1) DEFAULT NULL,
  `user_adress` varchar(50) DEFAULT NULL,
  `user_tel` varchar(15) DEFAULT NULL,
  PRIMARY KEY (`user_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

/*Data for the table `tb_user` */

insert  into `tb_user`(`user_id`,`user_name`,`user_password`,`user_authority`,`user_adress`,`user_tel`) values ('0100110','樊启望','0100111',1,'火星','13006208761'),('0100110123','樊启望','0100111',1,'11','11111111111'),('0100119','樊启望','0100111',1,'','13006208761'),('1008611','黄颖菲','123123',1,'赣州','12345678912'),('123456','赵鹤鸣','123456',1,'南昌','12345678901'),('12345678','施思伊','666666',0,'南昌','13517088840'),('19951104','公子','123456',0,'南昌','12345678901'),('627896965','唐诗吟','123456',1,'','12345678901'),('888888','滕辉','666666',1,'芜湖','13685534210');

/*Table structure for table `tb_vip` */

DROP TABLE IF EXISTS `tb_vip`;

CREATE TABLE `tb_vip` (
  `vip_id` int(1) NOT NULL AUTO_INCREMENT,
  `vip_name` varchar(20) NOT NULL,
  `vip_discount` int(11) NOT NULL,
  PRIMARY KEY (`vip_id`)
) ENGINE=InnoDB AUTO_INCREMENT=5 DEFAULT CHARSET=utf8;

/*Data for the table `tb_vip` */

insert  into `tb_vip`(`vip_id`,`vip_name`,`vip_discount`) values (1,'普通会员',98),(2,'黄金会员',95),(3,'白金会员',90),(4,'非会员',100);

/*Table structure for table `userlogin` */

DROP TABLE IF EXISTS `userlogin`;

CREATE TABLE `userlogin` (
  `uuser` varchar(10) NOT NULL,
  `uid` varchar(10) DEFAULT NULL,
  PRIMARY KEY (`uuser`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

/*Data for the table `userlogin` */

insert  into `userlogin`(`uuser`,`uid`) values ('000','000'),('123','123'),('222','333'),('441','520');

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;
